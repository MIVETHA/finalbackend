# Role Management System

## Overview
The application uses a **frontend-based role system** with no backend authentication. Users login with name and email, and their role determines UI visibility and available features.

## RoleService

### Location
`src/app/services/role.service.ts`

### User Roles
```typescript
enum UserRole {
  CUSTOMER = 'CUSTOMER',
  STAFF = 'STAFF'
}
```

### Current User Interface
```typescript
interface CurrentUser {
  firstName: string;
  lastName: string;
  email: string;
  customerId?: number;
  staffId?: number;
  role: UserRole;
}
```

### Key Methods

#### `login(user: CurrentUser): void`
Sets the current user and stores in localStorage.
```typescript
this.roleService.login({
  firstName: 'John',
  lastName: 'Doe',
  email: 'john@example.com',
  role: UserRole.CUSTOMER,
});
```

#### `logout(): void`
Clears user session and localStorage.
```typescript
this.roleService.logout();
```

#### `getCurrentUser(): CurrentUser | null`
Returns the currently logged-in user.

#### `getCurrentRole(): UserRole | null`
Returns the current user's role.

#### `isLoggedIn(): boolean`
Checks if a user is logged in.

#### `isCustomer(): boolean`
Returns true if current role is CUSTOMER.

#### `isStaff(): boolean`
Returns true if current role is STAFF.

#### `hasRole(role: UserRole): boolean`
Generic role check method.

### Observable Streams

#### `currentUser$: Observable<CurrentUser | null>`
Emits the current user whenever it changes.

#### `role$: Observable<UserRole | null>`
Emits the current role whenever it changes.

### Usage in Components

#### Subscription Pattern
```typescript
constructor(private roleService: RoleService) {
  this.roleService.currentUser$.subscribe(user => {
    console.log('User changed:', user);
  });
}
```

#### Async Pipe Pattern (Recommended)
```html
<div *ngIf="(roleService.currentUser$ | async) as user">
  Hello {{ user.firstName }}
</div>
```

## HasRole Directive

### Location
`src/app/directives/has-role.directive.ts`

### Purpose
Structural directive for showing/hiding content based on user role.

### Usage Examples

#### Show Customer-Only Content
```html
<div *appHasRole="'CUSTOMER'">
  <a routerLink="/films">Browse Films</a>
  <a routerLink="/rentals">My Rentals</a>
</div>
```

#### Show Staff-Only Content
```html
<div *appHasRole="'STAFF'">
  <a routerLink="/films">Manage Films</a>
  <a routerLink="/rentals">All Rentals</a>
</div>
```

#### Show Public Content
```html
<div *appHasRole="null">
  <a routerLink="/login">Login</a>
  <a routerLink="/signup">Sign Up</a>
</div>
```

## Navigation by Role

### Header Component
The header dynamically shows different menus based on the user's role:

```typescript
export class HeaderComponent {
  currentUser$: Observable<CurrentUser | null>;

  constructor(private roleService: RoleService) {
    this.currentUser$ = this.roleService.currentUser$;
  }

  logout(): void {
    this.roleService.logout();
    this.router.navigate(['/']);
  }
}
```

### Template Example
```html
<!-- Customer Menu -->
<div *appHasRole="'CUSTOMER'">
  <a routerLink="/films">Films</a>
  <a routerLink="/rentals">My Rentals</a>
  <a routerLink="/payments">Payments</a>
</div>

<!-- Staff Menu -->
<div *appHasRole="'STAFF'">
  <a routerLink="/films">Films (Manage)</a>
  <a routerLink="/rentals">All Rentals</a>
  <a routerLink="/payments">All Payments</a>
</div>

<!-- Unauthenticated Menu -->
<div *ngIf="!(currentUser$ | async)">
  <a routerLink="/login">Login</a>
  <a routerLink="/signup">Sign Up</a>
</div>
```

## Data Persistence

### localStorage Keys
- `filmstore_user`: Stores complete user object (JSON)
- `filmstore_role`: Stores user role string

### Initialization
When the app loads, `RoleService` automatically:
1. Reads user from localStorage
2. Restores the role
3. Emits via observables

```typescript
private loadUserFromStorage(): CurrentUser | null {
  try {
    const stored = localStorage.getItem('filmstore_user');
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}
```

## Common Patterns

### Protecting Content by Role

```typescript
// In component
canViewContent(): boolean {
  return this.roleService.isCustomer();
}
```

```html
<!-- In template -->
<div *ngIf="canViewContent()">
  Content only for customers
</div>
```

### Conditional Navigation

```typescript
onLogin(): void {
  const role = this.activeTab === 'customer' 
    ? UserRole.CUSTOMER 
    : UserRole.STAFF;
  
  this.roleService.login(user);
  
  if (role === UserRole.CUSTOMER) {
    this.router.navigate(['/films']);
  } else {
    this.router.navigate(['/films']);
  }
}
```

## Future Enhancements

1. **Guards**: Add route guards for authenticated routes
2. **Permissions**: Extend system with granular permissions
3. **Backend Auth**: Integrate with Spring Boot JWT authentication
4. **Session Timeout**: Implement session expiration
5. **Multi-Device**: Handle logout on other devices
