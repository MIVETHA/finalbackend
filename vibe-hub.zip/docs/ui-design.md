# UI Design System

## Design Philosophy

The Film Rental Store frontend follows a **modern, clean, and professional** design approach with:
- Clear visual hierarchy
- Consistent spacing and sizing
- Accessible color schemes
- Smooth animations and transitions
- Mobile-first responsive design
- Intuitive user interactions

## Color Palette

### Primary Colors
- **Primary Blue** (`primary-*`): Used for main actions, headers, and primary navigation
  - Primary-900: `#0c3d66` (Dark, headers)
  - Primary-800: `#075985`
  - Primary-700: `#0369a1`
  - Primary-600: `#0284c7` (Primary buttons)
  - Primary-500: `#0ea5e9`
  - Primary-200: `#bae6fd`
  - Primary-100: `#e0f2fe`

### Accent Colors
- **Accent Purple** (`accent-*`): Used for secondary actions and highlights
  - Accent-700: `#7e22ce` (Dark accent)
  - Accent-600: `#9333ea` (Accent buttons)
  - Accent-500: `#a855f7`

### Neutral Colors
- **Gray Scale**: For text, borders, backgrounds
  - Gray-900: `#111827` (Primary text)
  - Gray-600: `#4b5563` (Secondary text)
  - Gray-300: `#d1d5db` (Borders)
  - Gray-50: `#f9fafb` (Backgrounds)

### Status Colors
- **Success**: Green (`green-600`)
- **Error**: Red (`red-600`)
- **Warning**: Yellow (`yellow-500`)
- **Info**: Blue (`primary-600`)

## Typography

### Font Family
- Primary: **Inter** (modern, clean, default system sans-serif)

### Font Sizes
- **Display**: 48px (h1 in hero section)
- **Heading 1**: 36px (page titles)
- **Heading 2**: 28px (section titles)
- **Heading 3**: 20px (subsection titles)
- **Body**: 16px (main text)
- **Small**: 14px (secondary text, labels)
- **Tiny**: 12px (captions, meta information)

### Font Weights
- **Bold**: 700 (headings, call-to-action)
- **Semibold**: 600 (button text, strong emphasis)
- **Normal**: 400 (body text)

## Spacing

### Consistent Spacing Scale
- `px-2` / `py-2`: 8px (smallest)
- `px-4` / `py-4`: 16px (small)
- `px-6` / `py-6`: 24px (medium)
- `px-8` / `py-8`: 32px (large)
- `px-16` / `py-16`: 64px (extra large)

### Component Padding
- Buttons: `py-3 px-4` (12px vertical, 16px horizontal)
- Cards: `p-6` (24px all sides)
- Page sections: `py-8` to `py-16` (32px to 64px vertical)
- Form fields: `px-4 py-3` (12px vertical, 16px horizontal)

## Components

### Header / Navigation Bar
**Location**: `src/app/components/header/header.component.ts`

**Design Features:**
- Gradient background: `from-primary-900 to-primary-800`
- Sticky positioning: `sticky top-0 z-50`
- Responsive: Desktop nav visible, mobile menu with toggle
- Brand logo with icon
- Dynamic menu based on user role
- User info display with logout button
- Smooth transitions on hover

**States:**
- Active link: `bg-primary-700`
- Hover: `hover:bg-primary-700`

### Buttons

#### Primary Button
```html
<button class="px-4 py-3 bg-primary-600 hover:bg-primary-700 
  text-white font-semibold rounded-lg transition-colors">
  Click Me
</button>
```
- Background: Primary blue
- Text: White, semibold
- Hover: Darker blue
- Rounded corners: 8px
- Smooth transition on hover

#### Accent Button (Secondary CTA)
```html
<button class="px-4 py-3 bg-accent-600 hover:bg-accent-700 
  text-white font-semibold rounded-lg transition-colors">
  Secondary Action
</button>
```
- Background: Purple accent
- Used for secondary actions like "Rent Now", "Sign Up"

#### Ghost Button
```html
<button class="px-4 py-3 bg-gray-200 hover:bg-gray-300 
  text-gray-800 font-semibold rounded-lg transition-colors">
  Tertiary Action
</button>
```
- Used for tertiary actions or "Clear" buttons

### Form Fields

#### Input Fields
```html
<input type="text" 
  class="w-full px-4 py-3 border border-gray-300 rounded-lg 
  focus:outline-none focus:ring-2 focus:ring-primary-500 
  focus:border-transparent transition-colors"
/>
```
- Border: Gray 300
- Focus ring: Primary color (2px)
- Border disappears on focus
- Padding: 12px vertical, 16px horizontal
- Rounded: 8px

#### Dropdown/Select
- Same styling as input fields
- Clear option labels
- Easy keyboard navigation

### Cards

```html
<div class="bg-white rounded-xl shadow-md hover:shadow-xl 
  transition-shadow overflow-hidden">
  <!-- Card content -->
</div>
```
- Background: White
- Border radius: 12px (rounded-xl)
- Shadow: Material-like, lifting on hover
- Smooth shadow transition
- Padding: Varies by content (usually 24px)

### Film Cards (Grid Items)
**Structure:**
1. Image/Poster area (gradient placeholder)
2. Hover overlay with play icon
3. Film information section
   - Title (2 lines max)
   - Genre/Language badge
   - Release year badge
   - Description (2 lines max)
4. Rating and price
5. Action buttons (View Details, Rent Now)

**Design:**
```html
<div class="bg-white rounded-xl shadow-md hover:shadow-xl 
  transition-shadow overflow-hidden group">
  <!-- Poster -->
  <div class="relative bg-gradient-to-br from-primary-300 to-primary-600 
    h-64 flex items-center justify-center overflow-hidden group-hover:">
    <!-- Hover overlay -->
    <div class="absolute inset-0 bg-black/50 opacity-0 
      group-hover:opacity-100 transition-opacity">
  </div>
</div>
```

### Badges / Tags
```html
<span class="inline-block px-2 py-1 bg-primary-100 
  text-primary-700 text-xs font-semibold rounded">
  Label
</span>
```
- Small padding
- Matching text and background color
- Font: Bold, small
- Rounded: 4px

### Alerts / Messages

#### Error Alert
```html
<div class="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
  Error message
</div>
```

#### Success Alert
```html
<div class="p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
  Success message
</div>
```

#### Info Alert
```html
<div class="p-4 bg-blue-50 border border-blue-200 rounded-lg text-blue-700">
  Info message
</div>
```

## Responsive Breakpoints

Using Tailwind's responsive prefixes:

| Breakpoint | Width | Usage |
|-----------|-------|-------|
| `sm` | 640px | Small mobile devices |
| `md` | 768px | Tablets |
| `lg` | 1024px | Desktops |
| `xl` | 1280px | Large screens |

### Layout Examples

#### Two-Column (Films + Sidebar)
```html
<div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
  <div class="lg:col-span-1"><!-- Sidebar --></div>
  <div class="lg:col-span-3"><!-- Main Content --></div>
</div>
```
- Mobile: Full-width stacked
- Tablet & Desktop: Sidebar + Main

#### Grid Card Layout
```html
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
  <!-- Cards -->
</div>
```
- Mobile: Single column
- Tablet+: Two columns

## Animations & Transitions

### Hover Effects
- Button scale: `hover:scale-105`
- Shadow: `hover:shadow-xl transition-shadow`
- Color: `transition-colors`
- Opacity: `transition-opacity`

### Smooth Transitions
- Duration: Default 150ms
- Easing: Tailwind's default `cubic-bezier(0.4, 0, 0.2, 1)`

### Loading Spinner
```html
<svg class="animate-spin h-12 w-12 text-primary-600">
  <!-- SVG paths for spinner -->
</svg>
```
- Smooth infinite rotation
- Primary color
- Size: 12px (h-12 w-12)

## Accessibility

### Color Contrast
- All text meets WCAG AA standards
- Primary text on white: 9:1 contrast ratio
- Buttons have clear visual distinction

### Interactive Elements
- All buttons have clear hover/focus states
- Form labels properly associated with inputs
- Focus ring on interactive elements
- Keyboard navigable throughout

### Screen Readers
- Semantic HTML (`<header>`, `<nav>`, `<main>`, etc.)
- ARIA labels where needed
- Image alt text for decorative elements
- Skip links for navigation (future)

## Dark Mode (Future)

Currently supporting light mode. Dark mode can be added using:
```css
@media (prefers-color-scheme: dark) {
  /* Dark mode styles */
}
```

## Design System Files

### Main Config
- `tailwind.config.js`: Color definitions, theme extension
- `src/styles.css`: Global styles, Tailwind imports

### Component Files
- `src/app/components/`: Reusable UI components
- `src/app/pages/`: Page-level components

## Icons

Currently using:
- **Inline SVGs**: Custom SVG icons in components
- **Emoji**: Quick visual indicators (🎬, 👤, 💳, etc.)

**Future Enhancement:** Consider Icon Font or Icon Library (e.g., Feather Icons, Heroicons)

## Performance Optimizations

### CSS
- Tailwind CSS purging unused styles in production
- Critical CSS inline in HTML head
- Minimal custom CSS

### Images
- SVG placeholders (no image assets needed initially)
- Future: Lazy loading, responsive images with srcset

### JavaScript
- Standalone Angular components
- OnPush change detection
- Unsubscribe from observables
- Tree-shaking for unused code

## Browser Support

- Chrome/Chromium: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- Edge: Latest 2 versions

## Tools & Libraries

- **Tailwind CSS**: v3.4.11
- **Angular**: v20.1.0
- **TypeScript**: v5.8.2
- **PostCSS**: v8.5.6 (for Tailwind)

## Design Decisions

### Why Tailwind CSS?
- Utility-first approach for rapid UI development
- Consistent spacing and naming
- Small bundle size with purging
- Easy customization via config
- Great responsive support

### Why Standalone Components?
- Smaller bundle sizes
- Clear component dependencies
- Modern Angular development
- Tree-shaking friendly

### Why Blue & Purple?
- Professional, modern color scheme
- Good contrast for accessibility
- Differentiates primary (blue) and secondary (purple) actions
- Works well in both light and dark contexts

## Future Enhancements

1. **Storybook**: Component library for design documentation
2. **Dark Mode**: CSS custom properties for theme switching
3. **Animations**: More sophisticated micro-interactions
4. **Icon Library**: Consolidated SVG/icon system
5. **Design Tokens**: CSS custom properties for theming
