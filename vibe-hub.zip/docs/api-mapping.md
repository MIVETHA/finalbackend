# API Mapping & Backend Integration

## API Service Location
`src/app/services/api.service.ts`

## Base URL Configuration
```typescript
const API_BASE = 'http://localhost:8080/api';
```

**⚠️ UPDATE THIS** when backend URL is finalized.

## Endpoints Mapping

### Films Endpoints

#### Get All Films (with optional filters)
**Frontend Method:**
```typescript
getAllFilms(filters?: {
  actorId?: number;
  categoryId?: number;
  languageId?: number;
  minRating?: number;
  releaseYear?: number;
}): Observable<FilmDto[]>
```

**Backend Endpoint:**
```
GET /api/films?actorId=1&categoryId=2&languageId=1&minRating=3&releaseYear=2020
```

**Status:** ⏳ Waiting for backend implementation

---

#### Get Film by ID
**Frontend Method:**
```typescript
getFilmById(id: number): Observable<FilmDto>
```

**Backend Endpoint:**
```
GET /api/films/{id}
```

**Status:** ⏳ Waiting for backend

---

#### Create Film (Staff)
**Frontend Method:**
```typescript
createFilm(film: Partial<FilmDto>): Observable<FilmDto>
```

**Backend Endpoint:**
```
POST /api/films
Content-Type: application/json
{
  "title": "...",
  "description": "...",
  "releaseYear": 2024,
  "languageId": 1,
  "rentalRate": 5.99,
  "length": 120,
  "replacementCost": 25.00,
  "rating": 4,
  "specialFeatures": "..."
}
```

**Status:** ⏳ Waiting for backend

---

#### Update Film (Staff)
**Frontend Method:**
```typescript
updateFilm(id: number, film: Partial<FilmDto>): Observable<FilmDto>
```

**Backend Endpoint:**
```
PUT /api/films/{id}
Content-Type: application/json
```

**Status:** ⏳ Waiting for backend

---

#### Delete Film (Staff)
**Frontend Method:**
```typescript
deleteFilm(id: number): Observable<void>
```

**Backend Endpoint:**
```
DELETE /api/films/{id}
```

**Status:** ⏳ Waiting for backend

---

### Actor Endpoints

#### Get All Actors
**Frontend Method:**
```typescript
getAllActors(): Observable<ActorDto[]>
```

**Backend Endpoint:**
```
GET /api/actors
```

**Response Format:**
```json
[
  {
    "id": 1,
    "firstName": "Tom",
    "lastName": "Hanks"
  }
]
```

**Status:** ⏳ Waiting for backend

---

### Category Endpoints

#### Get All Categories
**Frontend Method:**
```typescript
getAllCategories(): Observable<CategoryDto[]>
```

**Backend Endpoint:**
```
GET /api/categories
```

**Response Format:**
```json
[
  {
    "categoryId": 1,
    "name": "Action"
  }
]
```

**Status:** ⏳ Waiting for backend

---

### Language Endpoints

#### Get All Languages
**Frontend Method:**
```typescript
getAllLanguages(): Observable<LanguageDTO[]>
```

**Backend Endpoint:**
```
GET /api/languages
```

**Response Format:**
```json
[
  {
    "languageId": 1,
    "name": "English"
  }
]
```

**Status:** ⏳ Waiting for backend

---

### Customer Endpoints

#### Create Customer (Sign Up)
**Frontend Method:**
```typescript
createCustomer(customer: Partial<CustomerDto>): Observable<CustomerDto>
```

**Backend Endpoint:**
```
POST /api/customers
Content-Type: application/json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "active": true
}
```

**Status:** ⏳ Waiting for backend

---

#### Get Customer by ID
**Frontend Method:**
```typescript
getCustomerById(id: number): Observable<CustomerDto>
```

**Backend Endpoint:**
```
GET /api/customers/{id}
```

**Status:** ⏳ Waiting for backend

---

### Rental Endpoints

#### Get All Rentals (Staff)
**Frontend Method:**
```typescript
getAllRentals(): Observable<RentalDto[]>
```

**Backend Endpoint:**
```
GET /api/rentals
```

**Status:** ⏳ Waiting for backend

---

#### Get Rentals by Customer ID
**Frontend Method:**
```typescript
getRentalsByCustomerId(customerId: number): Observable<RentalDto[]>
```

**Backend Endpoint:**
```
GET /api/rentals/customer/{customerId}
```

**Status:** ⏳ Waiting for backend

---

#### Create Rental
**Frontend Method:**
```typescript
createRental(rental: Partial<RentalDto>): Observable<RentalDto>
```

**Backend Endpoint:**
```
POST /api/rentals
Content-Type: application/json
{
  "rentalDate": "2024-01-15T10:30:00",
  "customerId": 1,
  "inventoryId": 5,
  "staffId": 2
}
```

**Status:** ⏳ Waiting for backend

---

#### Return Rental
**Frontend Method:**
```typescript
returnRental(rentalId: number): Observable<RentalDto>
```

**Backend Endpoint:**
```
PUT /api/rentals/{rentalId}/return
```

**Status:** ⏳ Waiting for backend

---

### Payment Endpoints

#### Get All Payments (Staff)
**Frontend Method:**
```typescript
getAllPayments(): Observable<PaymentDTO[]>
```

**Backend Endpoint:**
```
GET /api/payments
```

**Status:** ⏳ Waiting for backend

---

#### Get Payments by Customer ID
**Frontend Method:**
```typescript
getPaymentsByCustomerId(customerId: number): Observable<PaymentDTO[]>
```

**Backend Endpoint:**
```
GET /api/payments/customer/{customerId}
```

**Status:** ⏳ Waiting for backend

---

#### Create Payment
**Frontend Method:**
```typescript
createPayment(payment: Partial<PaymentDTO>): Observable<PaymentDTO>
```

**Backend Endpoint:**
```
POST /api/payments
Content-Type: application/json
{
  "customerId": 1,
  "rentalId": 5,
  "amount": 29.95,
  "paymentDate": "2024-01-20T15:45:00"
}
```

**Status:** ⏳ Waiting for backend

---

### Inventory Endpoints

#### Get All Inventory
**Frontend Method:**
```typescript
getAllInventory(): Observable<InventoryDTO[]>
```

**Backend Endpoint:**
```
GET /api/inventory
```

**Status:** ⏳ Waiting for backend

---

#### Get Inventory by Film ID
**Frontend Method:**
```typescript
getInventoryByFilmId(filmId: number): Observable<InventoryDTO[]>
```

**Backend Endpoint:**
```
GET /api/inventory/film/{filmId}
```

**Status:** ⏳ Waiting for backend

---

## DTOs (Data Transfer Objects)

### FilmDto
```typescript
interface FilmDto {
  filmId: number;
  title: string;
  description?: string;
  releaseYear?: number;
  rentalRate: number;
  length?: number;
  replacementCost?: number;
  rating?: number;
  specialFeatures?: string;
  languageId: number;
  languageName?: string;
  lastUpdate?: string;
}
```

### ActorDto
```typescript
interface ActorDto {
  id: number;
  firstName: string;
  lastName: string;
}
```

### CategoryDto
```typescript
interface CategoryDto {
  categoryId: number;
  name: string;
}
```

### LanguageDTO
```typescript
interface LanguageDTO {
  languageId: number;
  name: string;
}
```

### CustomerDto
```typescript
interface CustomerDto {
  customerId: number;
  firstName: string;
  lastName: string;
  email: string;
  active: boolean;
  storeId?: number;
  addressId?: number;
}
```

### RentalDto
```typescript
interface RentalDto {
  rentalId: number;
  rentalDate: string;
  returnDate?: string;
  customerId: number;
  inventoryId: number;
  staffId: number;
  lastUpdate: string;
}
```

### PaymentDTO
```typescript
interface PaymentDTO {
  paymentId: number;
  customerId: number;
  rentalId: number;
  amount: number;
  paymentDate: string;
  lastUpdate: string;
}
```

### InventoryDTO
```typescript
interface InventoryDTO {
  inventoryId: number;
  filmId: number;
  storeId: number;
  lastUpdate: string;
}
```

## Error Handling

Currently, errors are logged to console. Future enhancements:
- Error interceptor for consistent error handling
- User-friendly error messages
- Retry logic for failed requests
- Timeout handling

## CORS Configuration

**Required Backend CORS Settings:**
```
Access-Control-Allow-Origin: http://localhost:3000 (dev)
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: Content-Type, Authorization
```

## Authentication

**Current:** No authentication (demo mode - frontend only)

**Future:** 
- JWT token-based auth with Spring Boot
- Token refresh mechanism
- Secure token storage
- Auth interceptor for all requests
