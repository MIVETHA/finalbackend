# Film Filtering Logic

## Overview
The Films page (`/films`) provides multiple filter options to help users discover films based on their preferences.

## Available Filters

| Filter | Type | Source | Implementation |
|--------|------|--------|-----------------|
| **Actor** | Dropdown | Backend (ActorDto) | Frontend filtering (ready for backend) |
| **Category** | Dropdown | Backend (CategoryDto) | Frontend filtering (ready for backend) |
| **Language** | Dropdown | Backend (LanguageDTO) | ✅ Implemented |
| **Minimum Rating** | Dropdown (1-5) | Backend (FilmDto) | ✅ Implemented |
| **Release Year** | Text Input | Backend (FilmDto) | ✅ Implemented |

## Current Implementation

### Frontend Filtering
Currently, filtering is done on the **frontend** after loading all films from the backend.

**Location:** `src/app/pages/films/films.component.ts`

```typescript
applyFilters(): void {
  this.filteredFilms = this.films.filter((film) => {
    if (this.selectedLanguageId && film.languageId !== this.selectedLanguageId) {
      return false;
    }
    if (this.selectedMinRating && (!film.rating || film.rating < this.selectedMinRating)) {
      return false;
    }
    if (this.selectedYear && film.releaseYear !== this.selectedYear) {
      return false;
    }
    return true;
  });
}
```

### Filter State Management

```typescript
export class FilmsComponent {
  selectedActorId: number | null = null;
  selectedCategoryId: number | null = null;
  selectedLanguageId: number | null = null;
  selectedMinRating: number | null = null;
  selectedYear: number | null = null;
}
```

### On Filter Change

```typescript
onFilterChange(): void {
  this.applyFilters();
}

clearFilters(): void {
  this.selectedActorId = null;
  this.selectedCategoryId = null;
  this.selectedLanguageId = null;
  this.selectedMinRating = null;
  this.selectedYear = null;
  this.filteredFilms = this.films;
}
```

## Data Loading

### Load Sequence
```
1. Page loads
2. Promise.all([
     getAllFilms(),        // Fetch all films
     getAllActors(),       // Fetch all actors
     getAllCategories(),   // Fetch all categories
     getAllLanguages()     // Fetch all languages
   ])
3. Enrich films with language names
4. Display all films
5. Users apply filters
```

### Code Example
```typescript
ngOnInit(): void {
  this.loadData();
}

loadData(): void {
  this.isLoading = true;

  Promise.all([
    this.apiService.getAllFilms().toPromise(),
    this.apiService.getAllActors().toPromise(),
    this.apiService.getAllCategories().toPromise(),
    this.apiService.getAllLanguages().toPromise(),
  ]).then(
    ([films, actors, categories, languages]) => {
      this.films = films || [];
      this.actors = actors || [];
      this.categories = categories || [];
      this.languages = languages || [];

      // Add language name to films for display
      this.films = this.films.map((film) => ({
        ...film,
        languageName: this.languages.find((l) => l.languageId === film.languageId)?.name,
      }));

      this.filteredFilms = this.films;
      this.isLoading = false;
    },
    (error) => {
      console.error('Failed to load films:', error);
      this.isLoading = false;
    }
  );
}
```

## Future: Backend Filtering

### Recommended Approach
Once backend supports filtering parameters, update the `getAllFilms()` method to send filters:

```typescript
// Current
getAllFilms(): Observable<FilmDto[]>

// Future
getAllFilms(filters?: FilterParams): Observable<FilmDto[]> {
  let params = new HttpParams();
  if (filters?.actorId) params = params.set('actorId', filters.actorId);
  if (filters?.categoryId) params = params.set('categoryId', filters.categoryId);
  if (filters?.languageId) params = params.set('languageId', filters.languageId);
  if (filters?.minRating) params = params.set('minRating', filters.minRating);
  if (filters?.releaseYear) params = params.set('releaseYear', filters.releaseYear);
  
  return this.http.get<FilmDto[]>(`${API_BASE}/films`, { params });
}
```

### Updated Component Logic
```typescript
onFilterChange(): void {
  this.isLoading = true;
  
  this.apiService.getAllFilms({
    actorId: this.selectedActorId,
    categoryId: this.selectedCategoryId,
    languageId: this.selectedLanguageId,
    minRating: this.selectedMinRating,
    releaseYear: this.selectedYear,
  }).subscribe({
    next: (films) => {
      this.films = films;
      this.filteredFilms = films;
      this.isLoading = false;
    },
    error: () => {
      this.isLoading = false;
    }
  });
}
```

## Multiple Filter Combinations

### Logic
Filters work with **AND** logic:
- Film must match **ALL** selected filters
- If a filter is not selected (null), it's ignored
- Empty result set shows "No Films Found" message

### Example
If user selects:
- Language: English (languageId = 1)
- Min Rating: 4 stars
- Year: 2020

Only films where:
- `languageId === 1` **AND**
- `rating >= 4` **AND**
- `releaseYear === 2020`

will be displayed.

## Empty State

### When No Films Match
```typescript
<div *ngIf="!isLoading && filteredFilms.length === 0" class="text-center py-16">
  <h3 class="text-xl font-bold text-gray-900 mb-2">No Films Found</h3>
  <p class="text-gray-600 mb-6">Try adjusting your filters to find more films</p>
  <button (click)="clearFilters()">Clear Filters</button>
</div>
```

### User Experience
- Loading spinner during fetch
- Clear "No Films Found" message
- "Clear Filters" button to reset all selections
- All filters remain visible for adjustment

## Performance Considerations

### Current (Frontend Filtering)
- ✅ Instant filter changes
- ✅ No network latency
- ❌ Loads all films (scalability issue with large datasets)
- ❌ No server-side optimization

### Recommended (Backend Filtering)
- ✅ Scales to millions of films
- ✅ Server-side optimization (indexes, queries)
- ✅ Pagination support
- ❌ Network latency for each filter change
- Solution: Debounce filter changes to reduce requests

### Debounce Example (Future)
```typescript
import { debounceTime } from 'rxjs/operators';

filterChanged$ = new Subject<void>();

constructor() {
  this.filterChanged$
    .pipe(debounceTime(300)) // Wait 300ms before filtering
    .subscribe(() => this.onFilterChange());
}

onFilterChange(): void {
  this.filterChanged$.next();
}
```

## Accessibility

### Filter Form
- All inputs have associated labels
- Keyboard navigable dropdowns
- Clear visual feedback on focus
- Error states clearly indicated

### Film Grid
- Alt text for images (when implemented)
- Semantic HTML structure
- Clear call-to-action buttons
- Sufficient color contrast

## Testing Strategy

### Unit Tests
- Filter state management
- Apply filters logic
- Clear filters functionality
- Data loading

### Integration Tests
- API calls for films, actors, categories, languages
- Filter persistence
- Empty state display
- Error handling

### E2E Tests
- User selects filters
- Verify correct films displayed
- Verify clear filters works
- Verify navigation to film details
