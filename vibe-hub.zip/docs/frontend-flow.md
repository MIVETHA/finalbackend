# Film Rental Store - Frontend Flow & Route Map

## User Flows

### Customer Flow
```
Home (/) 
  → Login (/login) 
    → Films (/films) 
      → Film Details (/films/:id) [Rent Film]
    → My Rentals (/rentals)
    → Payments (/payments)
```

### Staff Flow
```
Home (/) 
  → Login (/login) 
    → Films (/films) [Manage Films]
    → All Rentals (/rentals)
    → All Payments (/payments)
```

### Public/Unauthenticated Flow
```
Home (/) 
  → Login (/login)
  → Sign Up (/signup) [Customer Registration]
```

## Route Map

| Route | Component | Access | Purpose |
|-------|-----------|--------|---------|
| `/` | `HomeComponent` | Public | Landing page with hero section |
| `/login` | `LoginComponent` | Public | Login with Customer/Staff tabs |
| `/signup` | `SignupComponent` | Public | Customer registration |
| `/films` | `FilmsComponent` | Logged In | Browse & filter films |
| `/films/:id` | `FilmDetailsComponent` | Logged In | Film details & rent |
| `/rentals` | `RentalsComponent` | Logged In | Rental history/management |
| `/payments` | `PaymentsComponent` | Logged In | Payment history/management |
| `**` | `NotFoundComponent` | Public | 404 Error Page |

## Authentication & Role-Based Navigation

### Login Process
1. User clicks "Login" on home page
2. Selects role: **Customer** or **Staff**
3. Enters: First Name, Last Name, Email ID
4. **NO PASSWORD REQUIRED** (demo mode)
5. Form validated on frontend only
6. Role stored in `RoleService`
7. User data persisted in localStorage
8. Navigation based on role:
   - **Customer** → `/films`
   - **Staff** → `/films`

### Sign Up Process (Customer Only)
1. User clicks "Sign Up"
2. Fills registration form:
   - First Name
   - Last Name
   - Email ID
3. Backend creates Customer record
4. Auto-login on success
5. Redirect to `/films`

### Navigation by Role

**Customer Menu:**
- Home
- Films (Browse & Filter)
- My Rentals
- Payments

**Staff Menu:**
- Home
- Films (Manage)
- All Rentals
- All Payments

**Both Roles:**
- User info display
- Logout button

## Component Hierarchy

```
App Component
├── Header Component (Role-aware navigation)
├── Router Outlet
│   ├── Home Page
│   ├── Login Page
│   ├── Sign Up Page
│   ├── Films Page (with Filters)
│   ├── Film Details Page
│   ├── Rentals Page
│   ├── Payments Page
│   └── Not Found Page
└── [Footer - Future]
```

## Data Flow

### Services Used
- **RoleService**: User authentication & role management
- **ApiService**: Backend API communication
- **HttpClient**: HTTP requests

### State Management
- User data stored in `localStorage`
- Reactive streams via RxJS `BehaviorSubject`
- Component-level state for UI interactions

## Responsive Design
- Mobile-first approach
- Breakpoints: `sm` (640px), `md` (768px), `lg` (1024px)
- Sticky header for navigation
- Sidebar filters hidden on mobile
- Grid layouts adapt to screen size
