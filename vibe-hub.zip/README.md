# 🎬 Film Rental Store - Angular Frontend

A beautiful, modern, and production-ready Angular frontend for a full-stack film rental management system. Built with Angular 20, TypeScript, Tailwind CSS, and a clean architecture that's ready for integration with a Spring Boot backend.

## 🌟 Features

### ✅ Implemented
- **Responsive Design**: Mobile-first, works on all screen sizes
- **Modern UI**: Beautiful gradient headers, smooth transitions, and professional color scheme
- **Role-Based Access**: Customer and Staff roles with dynamic navigation
- **Authentication**: Frontend-based login with name and email (no password required for demo)
- **Films Browser**: Browse films with powerful filters (language, rating, year)
- **Film Details**: Full film information page with pricing and specs
- **Routing**: Complete routing setup with all pages pre-configured
- **API Service**: Ready-to-use API service with all endpoints mapped
- **Form Validation**: Client-side validation on all forms
- **Error Handling**: User-friendly error messages and empty states
- **Documentation**: Complete documentation for developers

### 🎯 Pages Implemented
1. **Home** (`/`) - Landing page with hero section and CTA buttons
2. **Login** (`/login`) - Customer/Staff login with tabs
3. **Sign Up** (`/signup`) - Customer registration form
4. **Films** (`/films`) - Films browser with filters
5. **Film Details** (`/films/:id`) - Individual film details
6. **Rentals** (`/rentals`) - Placeholder for rental history
7. **Payments** (`/payments`) - Placeholder for payment history
8. **404** (`**`) - Not found error page

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Angular CLI (optional)

### Installation & Setup

```bash
# Install dependencies
npm install

# Start development server
npm start

# The app will be available at http://localhost:4200
```

### Build for Production

```bash
npm run build

# Output will be in dist/ directory
```

## 📁 Project Structure

```
src/
├── app/
│   ├── services/
│   │   ├── api.service.ts           # Backend API communication
│   │   └── role.service.ts          # Role & authentication management
│   ├── directives/
│   │   └── has-role.directive.ts    # Role-based UI visibility
│   ├── components/
│   │   └── header/                  # Navigation header
│   ├── pages/
│   │   ├── home/                    # Landing page
│   │   ├── login/                   # Login page
│   │   ├── signup/                  # Sign up page
│   │   ├── films/                   # Films browser
│   │   ├── film-details/            # Film details page
│   │   ├── rentals/                 # Rentals placeholder
│   │   ├── payments/                # Payments placeholder
│   │   └── not-found/               # 404 page
│   ├── app.ts                       # Root component
│   ├── app.html                     # Root template
│   ├── app.routes.ts                # Route configuration
│   └── app.config.ts                # App configuration
├── styles.css                       # Global styles with Tailwind
├── index.html                       # HTML entry point
└── main.ts                          # Bootstrap file
```

## 🎨 Design System

### Colors
- **Primary Blue** (`primary-*`): Main actions, headers, navigation
- **Accent Purple** (`accent-*`): Secondary actions, highlights
- **Neutral Gray** (`gray-*`): Text, borders, backgrounds

### Typography
- **Font**: Inter (modern, clean, default system sans-serif)
- **Scale**: From 12px (captions) to 48px (hero titles)

### Components
- Buttons (primary, secondary, ghost)
- Form fields (inputs, selects)
- Cards with hover effects
- Film cards with overlay
- Badges and tags
- Alerts and messages
- Loading spinners

See `/docs/ui-design.md` for detailed design documentation.

## 🔐 Authentication & Roles

### Current Implementation (Demo)
- **NO Backend Authentication**: Frontend-only login
- **NO Password**: Uses name and email only
- **Role Storage**: Persisted in localStorage

### User Roles
1. **CUSTOMER**
   - Browse films
   - View film details
   - Rent films
   - View rental history
   - Make payments

2. **STAFF**
   - Manage films
   - View all rentals
   - View all payments
   - Access reports

### Login Flow
```
User enters name + email
        ↓
Validate on frontend
        ↓
Store in RoleService
        ↓
Persist to localStorage
        ↓
Navigate to films
```

## 🔄 API Integration

### Configured Endpoints
All endpoints are configured in `src/app/services/api.service.ts`:

**Base URL:** `http://localhost:8080/api` (update as needed)

#### Films
- `GET /films` - Get all films with optional filters
- `GET /films/:id` - Get film by ID
- `POST /films` - Create film (Staff only)
- `PUT /films/:id` - Update film (Staff only)
- `DELETE /films/:id` - Delete film (Staff only)

#### Actors
- `GET /actors` - Get all actors

#### Categories
- `GET /categories` - Get all categories

#### Languages
- `GET /languages` - Get all languages

#### Customers
- `POST /customers` - Create customer (Sign up)
- `GET /customers/:id` - Get customer by ID

#### Rentals
- `GET /rentals` - Get all rentals
- `GET /rentals/customer/:id` - Get customer rentals
- `POST /rentals` - Create rental
- `PUT /rentals/:id/return` - Return rental

#### Payments
- `GET /payments` - Get all payments
- `GET /payments/customer/:id` - Get customer payments
- `POST /payments` - Create payment

#### Inventory
- `GET /inventory` - Get all inventory
- `GET /inventory/film/:id` - Get film inventory

See `/docs/api-mapping.md` for complete API documentation.

## 📚 Documentation

The project includes comprehensive documentation:

- **`/docs/frontend-flow.md`** - Complete user flows and route map
- **`/docs/role-management.md`** - Authentication and role system documentation
- **`/docs/api-mapping.md`** - Backend API endpoints and DTOs
- **`/docs/filtering-logic.md`** - Film filtering implementation details
- **`/docs/ui-design.md`** - Design system and component documentation

## 🛠️ Technology Stack

### Core
- **Angular**: 20.1.0 (latest version)
- **TypeScript**: 5.8.2
- **RxJS**: 7.8.0 (Reactive programming)

### Styling
- **Tailwind CSS**: 3.4.11 (utility-first CSS)
- **PostCSS**: 8.5.6 (CSS processing)
- **Autoprefixer**: 10.4.21 (browser compatibility)

### Dev Tools
- **Vite**: Fast build tool
- **Karma & Jasmine**: Testing framework
- **Angular CLI**: 20.1.2 (development tooling)

## 🧪 Testing (Future)

```bash
# Run unit tests
npm run test

# Run e2e tests (when configured)
npm run e2e
```

## 📱 Responsive Breakpoints

- `sm` (640px): Small mobile devices
- `md` (768px): Tablets
- `lg` (1024px): Desktops
- `xl` (1280px): Large screens

All pages are fully responsive and tested on multiple screen sizes.

## 🎯 Key Features Explained

### Films Browser with Filters
- Load all films from backend
- Filter by: Language, Minimum Rating, Release Year
- Frontend filtering (ready for backend optimization)
- Shows "No Films Found" when appropriate

### Film Details Page
- Full film information display
- Pricing and rental duration info
- Rent button integration
- Back navigation to films list

### Role-Based Navigation
Using the `HasRoleDirective`:
```html
<div *appHasRole="'CUSTOMER'">
  Customer-only content
</div>

<div *appHasRole="'STAFF'">
  Staff-only content
</div>
```

### Form Validation
- Client-side validation on all forms
- Error messages for validation failures
- Success messages after submission
- Loading states during async operations

## 🔄 State Management

### Current Approach
- **RoleService**: Manages user state with RxJS BehaviorSubjects
- **localStorage**: Persists user data between sessions
- **Component State**: Local state for UI interactions

### Future Enhancements
- NgRx for complex state management
- Service workers for offline support
- IndexedDB for offline data storage

## 🚨 Error Handling

### Current Implementation
- Try-catch blocks for localStorage access
- Error messages for API failures
- User-friendly validation messages
- Console logging for debugging

### Future Enhancements
- Error interceptor for consistent handling
- Sentry integration for error tracking
- Retry logic for failed requests
- Timeout configuration

## 🎓 Learning Resources

### Angular Concepts Used
- Standalone components
- Structural directives
- Service injection
- Reactive forms
- RxJS observables and subjects
- Angular routing

### Tailwind CSS
- Utility-first approach
- Responsive design with prefixes
- Custom color configuration
- Component composition

## 📝 Code Style & Conventions

- **TypeScript**: Strict mode enabled
- **Naming**: CamelCase for variables, PascalCase for classes
- **Files**: One component per file
- **Imports**: Organized and sorted
- **Comments**: JSDoc for public methods

## 🔐 Security Notes

### Current
- ⚠️ **NO production authentication** - Demo/development only
- ⚠️ **NO password protection** - Name and email only
- ⚠️ **localStorage**: User data visible in browser storage

### Production Requirements
- Implement JWT tokens with Spring Boot
- Use HttpOnly cookies for tokens
- Add HTTPS enforcement
- Implement CSRF protection
- Add rate limiting
- Input sanitization and validation

## 🚀 Deployment

### Build
```bash
npm run build
```

### Deploy to Netlify
```bash
# Using Netlify CLI
npm install -g netlify-cli
netlify deploy --prod
```

### Deploy to Vercel
```bash
npm install -g vercel
vercel --prod
```

### Docker
```bash
docker build -t filmrent:latest .
docker run -p 4200:4200 filmrent:latest
```

## 📞 Support & Issues

For issues, questions, or feature requests:
1. Check the documentation in `/docs/` folder
2. Review existing issues in git history
3. Create detailed issue reports with:
   - Steps to reproduce
   - Expected vs actual behavior
   - Browser/environment info
   - Screenshots/logs

## 📄 License

This project is provided as-is for educational and commercial use.

## 🎉 Credits

Built with ❤️ using:
- Angular 20
- Tailwind CSS
- TypeScript
- And a lot of ☕

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Status**: Production Ready (awaiting backend integration)
