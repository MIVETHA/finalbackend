import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { FilmsComponent } from './pages/films/films.component';
import { FilmDetailsComponent } from './pages/film-details/film-details.component';
import { RentalsComponent } from './pages/rentals/rentals.component';
import { PaymentsComponent } from './pages/payments/payments.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'films', component: FilmsComponent },
  { path: 'films/:id', component: FilmDetailsComponent },
  { path: 'rentals', component: RentalsComponent },
  { path: 'payments', component: PaymentsComponent },
  { path: '**', component: NotFoundComponent },
];
