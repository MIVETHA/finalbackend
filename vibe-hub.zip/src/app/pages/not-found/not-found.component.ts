import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-primary-900 via-primary-800 to-primary-900 flex items-center justify-center px-4">
      <div class="text-center text-white">
        <h1 class="text-9xl font-bold mb-4">404</h1>
        <h2 class="text-4xl font-bold mb-4">Page Not Found</h2>
        <p class="text-xl text-primary-200 mb-8">The page you're looking for doesn't exist or has been moved.</p>
        <a routerLink="/"
          class="inline-block px-8 py-4 bg-accent-600 hover:bg-accent-500 text-white font-bold rounded-lg transition-colors transform hover:scale-105">
          🏠 Go to Home
        </a>
      </div>
    </div>
  `,
  styles: [],
})
export class NotFoundComponent {}
