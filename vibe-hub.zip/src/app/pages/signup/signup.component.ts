import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RoleService, UserRole } from '../../services/role.service';
import { ApiService } from '../../services/api.service';

interface SignupForm {
  firstName: string;
  lastName: string;
  email: string;
  storeId?: number;
  addressId?: number;
}

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center px-4 py-8">
      <div class="w-full max-w-md">
        <!-- Card -->
        <div class="bg-white rounded-xl shadow-2xl overflow-hidden">
          <!-- Header -->
          <div class="bg-gradient-to-r from-accent-600 to-accent-700 text-white p-8">
            <h1 class="text-3xl font-bold mb-2">Join FilmRent</h1>
            <p class="text-accent-100">Create your customer account and start renting films</p>
          </div>

          <!-- Form -->
          <div class="p-8">
            <form (ngSubmit)="onSignup()" #signupForm="ngForm">
              <!-- Error Alert -->
              <div *ngIf="errorMessage" class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
                {{ errorMessage }}
              </div>

              <!-- Success Alert -->
              <div *ngIf="successMessage" class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
                {{ successMessage }}
              </div>

              <!-- First Name -->
              <div class="mb-6">
                <label class="block text-sm font-semibold text-gray-700 mb-2">First Name</label>
                <input
                  type="text"
                  [(ngModel)]="form.firstName"
                  name="firstName"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-500 focus:border-transparent transition-colors"
                  placeholder="John"
                />
              </div>

              <!-- Last Name -->
              <div class="mb-6">
                <label class="block text-sm font-semibold text-gray-700 mb-2">Last Name</label>
                <input
                  type="text"
                  [(ngModel)]="form.lastName"
                  name="lastName"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-500 focus:border-transparent transition-colors"
                  placeholder="Doe"
                />
              </div>

              <!-- Email -->
              <div class="mb-8">
                <label class="block text-sm font-semibold text-gray-700 mb-2">Email ID</label>
                <input
                  type="email"
                  [(ngModel)]="form.email"
                  name="email"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-500 focus:border-transparent transition-colors"
                  placeholder="john@example.com"
                />
              </div>

              <!-- Submit Button -->
              <button
                type="submit"
                [disabled]="isLoading"
                class="w-full py-3 bg-gradient-to-r from-accent-600 to-accent-700 hover:from-accent-700 hover:to-accent-800 disabled:from-gray-400 disabled:to-gray-400 text-white font-bold rounded-lg transition-all transform hover:scale-105 disabled:hover:scale-100">
                {{ isLoading ? 'Creating Account...' : 'Create Account' }}
              </button>
            </form>

            <!-- Login Link -->
            <p class="text-center text-gray-600 mt-6">
              Already have an account?
              <a routerLink="/login" class="text-accent-600 hover:text-accent-700 font-semibold">
                Login here
              </a>
            </p>
          </div>
        </div>

        <!-- Info Box -->
        <div class="mt-8 bg-accent-50 border border-accent-200 rounded-lg p-6">
          <h3 class="font-bold text-accent-900 mb-2">Customer Benefits</h3>
          <ul class="text-accent-700 text-sm space-y-2">
            <li>✓ Browse thousands of films</li>
            <li>✓ Rent films instantly</li>
            <li>✓ Track your rental history</li>
            <li>✓ Manage your payments</li>
            <li>✓ Filter by category, actor, and language</li>
          </ul>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class SignupComponent implements OnInit {
  form: SignupForm = {
    firstName: '',
    lastName: '',
    email: '',
  };
  errorMessage = '';
  successMessage = '';
  isLoading = false;

  constructor(
    private roleService: RoleService,
    private apiService: ApiService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // If already logged in, redirect to films
    if (this.roleService.isLoggedIn()) {
      this.router.navigate(['/films']);
    }
  }

  onSignup(): void {
    // Validate form
    if (!this.form.firstName.trim() || !this.form.lastName.trim() || !this.form.email.trim()) {
      this.errorMessage = 'Please fill in all required fields';
      return;
    }

    // Email validation
    if (!this.form.email.includes('@')) {
      this.errorMessage = 'Please enter a valid email address';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    // Call backend API to create customer
    this.apiService.createCustomer({
      firstName: this.form.firstName,
      lastName: this.form.lastName,
      email: this.form.email,
      active: true,
    }).subscribe({
      next: (customer) => {
        this.successMessage = 'Account created successfully! Logging you in...';
        
        // Auto-login after successful signup
        setTimeout(() => {
          this.roleService.login({
            firstName: this.form.firstName,
            lastName: this.form.lastName,
            email: this.form.email,
            customerId: customer.customerId,
            role: UserRole.CUSTOMER,
          });
          
          this.isLoading = false;
          this.router.navigate(['/films']);
        }, 1000);
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = error.error?.message || 'Failed to create account. Please try again.';
      },
    });
  }
}
