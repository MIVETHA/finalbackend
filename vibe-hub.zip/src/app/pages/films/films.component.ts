import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ApiService, FilmDto, ActorDto, CategoryDto, LanguageDTO } from '../../services/api.service';
import { RoleService } from '../../services/role.service';

@Component({
  selector: 'app-films',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="min-h-screen bg-gray-50">
      <!-- Top Section -->
      <div class="bg-white border-b">
        <div class="max-w-7xl mx-auto px-4 py-8">
          <h1 class="text-4xl font-bold text-gray-900 mb-2">🎬 Films</h1>
          <p class="text-gray-600">Browse and discover your favorite films</p>
        </div>
      </div>

      <!-- Main Content -->
      <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <!-- Sidebar Filters -->
          <div class="lg:col-span-1">
            <div class="bg-white rounded-xl shadow-md p-6 sticky top-24">
              <h2 class="text-2xl font-bold text-gray-900 mb-6">Filters</h2>

              <!-- Actor Filter -->
              <div class="mb-6">
                <label class="block font-semibold text-gray-700 mb-3">Actor</label>
                <select
                  [(ngModel)]="selectedActorId"
                  (change)="onFilterChange()"
                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <option [value]="null">All Actors</option>
                  <option *ngFor="let actor of actors" [value]="actor.id">
                    {{ actor.firstName }} {{ actor.lastName }}
                  </option>
                </select>
              </div>

              <!-- Category Filter -->
              <div class="mb-6">
                <label class="block font-semibold text-gray-700 mb-3">Category</label>
                <select
                  [(ngModel)]="selectedCategoryId"
                  (change)="onFilterChange()"
                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <option [value]="null">All Categories</option>
                  <option *ngFor="let category of categories" [value]="category.categoryId">
                    {{ category.name }}
                  </option>
                </select>
              </div>

              <!-- Language Filter -->
              <div class="mb-6">
                <label class="block font-semibold text-gray-700 mb-3">Language</label>
                <select
                  [(ngModel)]="selectedLanguageId"
                  (change)="onFilterChange()"
                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <option [value]="null">All Languages</option>
                  <option *ngFor="let language of languages" [value]="language.languageId">
                    {{ language.name }}
                  </option>
                </select>
              </div>

              <!-- Min Rating Filter -->
              <div class="mb-6">
                <label class="block font-semibold text-gray-700 mb-3">Minimum Rating</label>
                <select
                  [(ngModel)]="selectedMinRating"
                  (change)="onFilterChange()"
                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <option [value]="null">Any Rating</option>
                  <option value="1">1+ ⭐</option>
                  <option value="2">2+ ⭐⭐</option>
                  <option value="3">3+ ⭐⭐⭐</option>
                  <option value="4">4+ ⭐⭐⭐⭐</option>
                  <option value="5">5 ⭐⭐⭐⭐⭐</option>
                </select>
              </div>

              <!-- Release Year Filter -->
              <div class="mb-6">
                <label class="block font-semibold text-gray-700 mb-3">Release Year</label>
                <input
                  type="number"
                  [(ngModel)]="selectedYear"
                  (change)="onFilterChange()"
                  placeholder="e.g., 2020"
                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <!-- Clear Filters Button -->
              <button
                (click)="clearFilters()"
                class="w-full py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold rounded-lg transition-colors">
                Clear Filters
              </button>
            </div>
          </div>

          <!-- Films Grid -->
          <div class="lg:col-span-3">
            <!-- Loading State -->
            <div *ngIf="isLoading" class="flex justify-center items-center py-16">
              <div class="text-center">
                <div class="inline-block">
                  <svg class="animate-spin h-12 w-12 text-primary-600" viewBox="0 0 50 50">
                    <circle class="opacity-30" cx="25" cy="25" r="20" stroke="currentColor" stroke-width="5" fill="none"/>
                    <circle class="text-primary-600" cx="25" cy="25" r="20" stroke="currentColor" stroke-width="5" fill="none" stroke-dasharray="100" stroke-dashoffset="75"/>
                  </svg>
                </div>
                <p class="mt-4 text-gray-600 font-semibold">Loading films...</p>
              </div>
            </div>

            <!-- Empty State -->
            <div *ngIf="!isLoading && filteredFilms.length === 0" class="text-center py-16">
              <svg class="w-16 h-16 mx-auto text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4v16m0 0H3m4 0h14M7 4l2 4m5-4l-2 4m5 0l2-4m0 16H3m18 0h4m-4 0l-2-4m5 4l2-4"/>
              </svg>
              <h3 class="text-xl font-bold text-gray-900 mb-2">No Films Found</h3>
              <p class="text-gray-600 mb-6">Try adjusting your filters to find more films</p>
              <button
                (click)="clearFilters()"
                class="inline-block px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors">
                Clear Filters
              </button>
            </div>

            <!-- Films Grid -->
            <div *ngIf="!isLoading && filteredFilms.length > 0" class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div
                *ngFor="let film of filteredFilms"
                class="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow overflow-hidden group">
                <!-- Poster Placeholder -->
                <div class="relative bg-gradient-to-br from-primary-300 to-primary-600 h-64 flex items-center justify-center overflow-hidden">
                  <svg class="w-24 h-24 text-white/30" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54h2.88l2.96-3.83.63 4.63h2.96L17.5 6.5z"/>
                  </svg>
                  <div class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <svg class="w-16 h-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z"/>
                    </svg>
                  </div>
                </div>

                <!-- Film Info -->
                <div class="p-6">
                  <h3 class="text-lg font-bold text-gray-900 mb-2 line-clamp-2">{{ film.title }}</h3>

                  <div class="flex flex-wrap gap-2 mb-3">
                    <span class="inline-block px-2 py-1 bg-primary-100 text-primary-700 text-xs font-semibold rounded">
                      {{ film.languageName || 'Unknown' }}
                    </span>
                    <span class="inline-block px-2 py-1 bg-accent-100 text-accent-700 text-xs font-semibold rounded">
                      {{ film.releaseYear || 'N/A' }}
                    </span>
                  </div>

                  <div class="text-sm text-gray-600 mb-4">
                    <p *ngIf="film.description" class="line-clamp-2">{{ film.description }}</p>
                    <p *ngIf="!film.description" class="italic">No description available</p>
                  </div>

                  <div class="flex items-center justify-between mb-4">
                    <div *ngIf="film.rating" class="text-lg font-bold text-yellow-500">
                      {{ film.rating }} ⭐
                    </div>
                    <div *ngIf="!film.rating" class="text-lg text-gray-400">
                      No rating
                    </div>
                    <div class="text-lg font-bold text-primary-600">
                      <span [textContent]="'$' + film.rentalRate + '/day'"></span>
                    </div>
                  </div>

                  <div class="flex gap-3">
                    <a
                      [routerLink]="['/films', film.filmId]"
                      class="flex-1 py-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors text-center block">
                      View Details
                    </a>
                    <button
                      (click)="onRentFilm(film)"
                      class="flex-1 py-2 bg-accent-600 hover:bg-accent-700 text-white font-semibold rounded-lg transition-colors">
                      Rent Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class FilmsComponent implements OnInit {
  films: FilmDto[] = [];
  filteredFilms: FilmDto[] = [];
  actors: ActorDto[] = [];
  categories: CategoryDto[] = [];
  languages: LanguageDTO[] = [];

  selectedActorId: number | null = null;
  selectedCategoryId: number | null = null;
  selectedLanguageId: number | null = null;
  selectedMinRating: number | null = null;
  selectedYear: number | null = null;

  isLoading = true;

  constructor(private apiService: ApiService, private roleService: RoleService) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.isLoading = true;

    Promise.all([
      this.apiService.getAllFilms().toPromise(),
      this.apiService.getAllActors().toPromise(),
      this.apiService.getAllCategories().toPromise(),
      this.apiService.getAllLanguages().toPromise(),
    ]).then(
      ([films, actors, categories, languages]) => {
        this.films = films || [];
        this.actors = actors || [];
        this.categories = categories || [];
        this.languages = languages || [];

        this.films = this.films.map((film) => ({
          ...film,
          languageName: this.languages.find((l) => l.languageId === film.languageId)?.name,
        }));

        this.filteredFilms = this.films;
        this.isLoading = false;
      },
      (error) => {
        console.error('Failed to load films:', error);
        this.isLoading = false;
      }
    );
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  applyFilters(): void {
    this.filteredFilms = this.films.filter((film) => {
      if (this.selectedLanguageId && film.languageId !== this.selectedLanguageId) {
        return false;
      }
      if (this.selectedMinRating && (!film.rating || film.rating < this.selectedMinRating)) {
        return false;
      }
      if (this.selectedYear && film.releaseYear !== this.selectedYear) {
        return false;
      }
      return true;
    });
  }

  clearFilters(): void {
    this.selectedActorId = null;
    this.selectedCategoryId = null;
    this.selectedLanguageId = null;
    this.selectedMinRating = null;
    this.selectedYear = null;
    this.filteredFilms = this.films;
  }

  onRentFilm(film: FilmDto): void {
    const user = this.roleService.getCurrentUser();
    if (!user) {
      alert('Please login first to rent a film');
      return;
    }

    alert(`Rental logic for ${film.title} to be implemented with backend API`);
  }
}
