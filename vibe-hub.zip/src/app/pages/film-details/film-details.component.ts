import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService, FilmDto } from '../../services/api.service';
import { RoleService } from '../../services/role.service';

@Component({
  selector: 'app-film-details',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="min-h-screen bg-gray-50">
      <!-- Loading State -->
      <div *ngIf="isLoading" class="flex justify-center items-center py-16">
        <div class="text-center">
          <svg class="animate-spin h-12 w-12 text-primary-600 mx-auto" viewBox="0 0 50 50">
            <circle class="opacity-30" cx="25" cy="25" r="20" stroke="currentColor" stroke-width="5" fill="none"/>
            <circle class="text-primary-600" cx="25" cy="25" r="20" stroke="currentColor" stroke-width="5" fill="none" stroke-dasharray="100" stroke-dashoffset="75"/>
          </svg>
          <p class="mt-4 text-gray-600 font-semibold">Loading film details...</p>
        </div>
      </div>

      <!-- Film Details -->
      <div *ngIf="!isLoading && film" class="max-w-5xl mx-auto px-4 py-8">
        <!-- Back Button -->
        <a routerLink="/films" class="inline-flex items-center gap-2 text-primary-600 hover:text-primary-700 font-semibold mb-6">
          ← Back to Films
        </a>

        <div class="grid md:grid-cols-3 gap-8">
          <!-- Poster -->
          <div class="md:col-span-1">
            <div class="bg-gradient-to-br from-primary-300 to-primary-600 rounded-xl aspect-video flex items-center justify-center">
              <svg class="w-32 h-32 text-white/30" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54h2.88l2.96-3.83.63 4.63h2.96L17.5 6.5z"/>
              </svg>
            </div>
          </div>

          <!-- Film Info -->
          <div class="md:col-span-2">
            <h1 class="text-4xl font-bold text-gray-900 mb-4">{{ film.title }}</h1>

            <!-- Meta Info -->
            <div class="flex flex-wrap gap-3 mb-6">
              <span class="px-3 py-1 bg-primary-100 text-primary-700 font-semibold rounded-lg">
                {{ film.languageName || 'Unknown Language' }}
              </span>
              <span class="px-3 py-1 bg-accent-100 text-accent-700 font-semibold rounded-lg">
                {{ film.releaseYear || 'N/A' }}
              </span>
              <span *ngIf="film.rating" class="px-3 py-1 bg-yellow-100 text-yellow-700 font-semibold rounded-lg">
                {{ film.rating }} ⭐
              </span>
            </div>

            <!-- Description -->
            <div class="mb-6">
              <h2 class="text-2xl font-bold text-gray-900 mb-2">Description</h2>
              <p *ngIf="film.description" class="text-gray-600 leading-relaxed">{{ film.description }}</p>
              <p *ngIf="!film.description" class="text-gray-400 italic">No description available</p>
            </div>

            <!-- Details Grid -->
            <div class="grid grid-cols-2 gap-4 mb-6">
              <div class="bg-white p-4 rounded-lg">
                <p class="text-gray-600 text-sm">Rental Rate</p>
                <p class="text-2xl font-bold text-primary-600">
                  <span [textContent]="formatPrice(film.rentalRate) + '/day'"></span>
                </p>
              </div>
              <div class="bg-white p-4 rounded-lg">
                <p class="text-gray-600 text-sm">Replacement Cost</p>
                <p class="text-2xl font-bold text-primary-600">
                  {{ film.replacementCost ? formatPrice(film.replacementCost) : 'N/A' }}
                </p>
              </div>
              <div class="bg-white p-4 rounded-lg">
                <p class="text-gray-600 text-sm">Duration</p>
                <p class="text-2xl font-bold text-primary-600">{{ film.length || 'N/A' }}<span class="text-sm text-gray-600"> min</span></p>
              </div>
              <div class="bg-white p-4 rounded-lg">
                <p class="text-gray-600 text-sm">Rental Duration</p>
                <p class="text-2xl font-bold text-primary-600">{{ film.rentalDuration || 'N/A' }}<span class="text-sm text-gray-600"> days</span></p>
              </div>
            </div>

            <!-- Special Features -->
            <div *ngIf="film.specialFeatures" class="mb-6">
              <h3 class="text-lg font-bold text-gray-900 mb-2">Special Features</h3>
              <p class="text-gray-600">{{ film.specialFeatures }}</p>
            </div>

            <!-- Action Buttons -->
            <div class="flex gap-4">
              <button
                (click)="onRentFilm()"
                class="flex-1 py-4 bg-accent-600 hover:bg-accent-700 text-white font-bold text-lg rounded-lg transition-colors">
                🎬 Rent Now
              </button>
              <a routerLink="/films" class="flex-1 py-4 bg-gray-300 hover:bg-gray-400 text-gray-900 font-bold text-lg rounded-lg transition-colors text-center">
                Continue Browsing
              </a>
            </div>
          </div>
        </div>
      </div>

      <!-- Not Found -->
      <div *ngIf="!isLoading && !film" class="text-center py-16">
        <svg class="w-16 h-16 mx-auto text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h3 class="text-xl font-bold text-gray-900 mb-2">Film Not Found</h3>
        <p class="text-gray-600 mb-6">The film you're looking for doesn't exist</p>
        <a routerLink="/films"
          class="inline-block px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors">
          Back to Films
        </a>
      </div>
    </div>
  `,
  styles: [],
})
export class FilmDetailsComponent implements OnInit {
  film: FilmDto | null = null;
  isLoading = true;

  constructor(
    private route: ActivatedRoute,
    private apiService: ApiService,
    private roleService: RoleService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      const filmId = parseInt(params['id'], 10);
      this.loadFilmDetails(filmId);
    });
  }

  loadFilmDetails(filmId: number): void {
    this.isLoading = true;
    this.apiService.getFilmById(filmId).subscribe({
      next: (film) => {
        this.film = film;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      },
    });
  }

  formatPrice(price: number): string {
    return `$${price.toFixed(2)}`;
  }

  onRentFilm(): void {
    const user = this.roleService.getCurrentUser();
    if (!user) {
      alert('Please login first to rent a film');
      return;
    }

    if (this.film) {
      alert(`Rental logic for ${this.film.title} to be implemented with backend API`);
    }
  }
}
