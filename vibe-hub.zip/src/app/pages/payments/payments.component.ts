import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="min-h-screen bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 py-16 text-center">
        <svg class="w-20 h-20 mx-auto text-gray-400 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h10m4 0a1 1 0 11-2 0 1 1 0 012 0z"/>
        </svg>
        <h1 class="text-4xl font-bold text-gray-900 mb-4">💳 Payments</h1>
        <p class="text-lg text-gray-600 mb-8">This page is being developed. Continue using the app to explore other features.</p>
        <a routerLink="/"
          class="inline-block px-8 py-3 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-lg transition-colors">
          Back to Home
        </a>
      </div>
    </div>
  `,
  styles: [],
})
export class PaymentsComponent {}
