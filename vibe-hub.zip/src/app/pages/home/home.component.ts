import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { RoleService } from '../../services/role.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-primary-900 via-primary-800 to-primary-900">
      <!-- Hero Section -->
      <div class="max-w-7xl mx-auto px-4 py-20 text-center text-white">
        <div class="mb-8 flex justify-center">
          <svg class="w-24 h-24 text-accent-400" fill="currentColor" viewBox="0 0 24 24">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54h2.88l2.96-3.83.63 4.63h2.96L17.5 6.5z"/>
          </svg>
        </div>

        <h1 class="text-6xl font-bold mb-4 leading-tight">
          🎬 Film Rental Store
        </h1>

        <p class="text-2xl text-primary-200 mb-8 max-w-2xl mx-auto">
          Rent your favorite films anytime. Discover thousands of movies, from classics to the latest releases.
        </p>

        <!-- Feature highlights -->
        <div class="grid md:grid-cols-3 gap-6 mb-12 max-w-4xl mx-auto">
          <div class="bg-primary-800/50 backdrop-blur border border-primary-700 rounded-xl p-6">
            <div class="text-4xl mb-3">🎯</div>
            <h3 class="font-bold text-lg mb-2">Easy Browsing</h3>
            <p class="text-primary-200 text-sm">Filter by category, actor, language, and more</p>
          </div>
          <div class="bg-primary-800/50 backdrop-blur border border-primary-700 rounded-xl p-6">
            <div class="text-4xl mb-3">🚀</div>
            <h3 class="font-bold text-lg mb-2">Quick Rentals</h3>
            <p class="text-primary-200 text-sm">Rent films in seconds and enjoy them instantly</p>
          </div>
          <div class="bg-primary-800/50 backdrop-blur border border-primary-700 rounded-xl p-6">
            <div class="text-4xl mb-3">💳</div>
            <h3 class="font-bold text-lg mb-2">Secure Payments</h3>
            <p class="text-primary-200 text-sm">Safe and easy payment options available</p>
          </div>
        </div>

        <!-- CTA Buttons -->
        <div *ngIf="!(isLoggedIn$ | async)" class="flex gap-4 justify-center flex-wrap">
          <a routerLink="/login"
            class="px-8 py-4 bg-accent-600 hover:bg-accent-500 text-white font-bold text-lg rounded-lg transition-all transform hover:scale-105 shadow-lg">
            Login to Rent Films
          </a>
          <a routerLink="/signup"
            class="px-8 py-4 bg-white hover:bg-gray-100 text-primary-900 font-bold text-lg rounded-lg transition-all transform hover:scale-105 shadow-lg">
            Create Account
          </a>
        </div>

        <div *ngIf="isLoggedIn$ | async" class="flex gap-4 justify-center flex-wrap">
          <a routerLink="/films"
            class="px-8 py-4 bg-accent-600 hover:bg-accent-500 text-white font-bold text-lg rounded-lg transition-all transform hover:scale-105 shadow-lg">
            Browse Films
          </a>
        </div>
      </div>

      <!-- Popular Categories Section -->
      <div class="max-w-7xl mx-auto px-4 py-20">
        <h2 class="text-4xl font-bold text-white mb-12 text-center">Popular Categories</h2>
        <div class="grid md:grid-cols-4 gap-6">
          <div class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-8 text-center cursor-pointer">
            <div class="text-5xl mb-4">🎭</div>
            <h3 class="font-bold text-xl text-gray-900">Drama</h3>
          </div>
          <div class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-8 text-center cursor-pointer">
            <div class="text-5xl mb-4">🎬</div>
            <h3 class="font-bold text-xl text-gray-900">Action</h3>
          </div>
          <div class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-8 text-center cursor-pointer">
            <div class="text-5xl mb-4">😄</div>
            <h3 class="font-bold text-xl text-gray-900">Comedy</h3>
          </div>
          <div class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-8 text-center cursor-pointer">
            <div class="text-5xl mb-4">🚀</div>
            <h3 class="font-bold text-xl text-gray-900">Sci-Fi</h3>
          </div>
        </div>
      </div>

      <!-- Footer Call to Action -->
      <div class="bg-gradient-to-r from-accent-600 to-accent-700 text-white py-16">
        <div class="max-w-4xl mx-auto text-center">
          <h2 class="text-3xl font-bold mb-4">Ready to Start Renting?</h2>
          <p class="text-lg mb-8">Join thousands of movie lovers enjoying unlimited entertainment</p>
          <a routerLink="/login"
            class="inline-block px-8 py-4 bg-white text-accent-700 font-bold rounded-lg hover:bg-gray-100 transition-colors">
            Get Started Now
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class HomeComponent {
  isLoggedIn$: Observable<any>;

  constructor(private roleService: RoleService) {
    this.isLoggedIn$ = this.roleService.currentUser$;
  }
}
