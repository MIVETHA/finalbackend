import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RoleService, UserRole } from '../../services/role.service';

interface LoginForm {
  firstName: string;
  lastName: string;
  email: string;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center px-4 py-8">
      <div class="w-full max-w-md">
        <!-- Card -->
        <div class="bg-white rounded-xl shadow-2xl overflow-hidden">
          <!-- Header -->
          <div class="bg-gradient-to-r from-primary-900 to-primary-800 text-white p-8">
            <h1 class="text-3xl font-bold mb-2">Welcome Back</h1>
            <p class="text-primary-200">Login to your film rental account</p>
          </div>

          <!-- Tabs -->
          <div class="flex border-b">
            <button
              (click)="activeTab = 'customer'"
              [class.bg-primary-50]="activeTab === 'customer'"
              [class.border-b-2]="activeTab === 'customer'"
              [class.border-primary-600]="activeTab === 'customer'"
              class="flex-1 py-4 font-semibold text-center transition-colors"
              [class.text-primary-600]="activeTab === 'customer'"
              [class.text-gray-600]="activeTab !== 'customer'">
              👤 Customer
            </button>
            <button
              (click)="activeTab = 'staff'"
              [class.bg-primary-50]="activeTab === 'staff'"
              [class.border-b-2]="activeTab === 'staff'"
              [class.border-primary-600]="activeTab === 'staff'"
              class="flex-1 py-4 font-semibold text-center transition-colors"
              [class.text-primary-600]="activeTab === 'staff'"
              [class.text-gray-600]="activeTab !== 'staff'">
              👨‍💼 Staff
            </button>
          </div>

          <!-- Form -->
          <div class="p-8">
            <form (ngSubmit)="onLogin()" #loginForm="ngForm">
              <!-- Error Alert -->
              <div *ngIf="errorMessage" class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
                {{ errorMessage }}
              </div>

              <!-- First Name -->
              <div class="mb-6">
                <label class="block text-sm font-semibold text-gray-700 mb-2">First Name</label>
                <input
                  type="text"
                  [(ngModel)]="form.firstName"
                  name="firstName"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-colors"
                  placeholder="Enter your first name"
                />
              </div>

              <!-- Last Name -->
              <div class="mb-6">
                <label class="block text-sm font-semibold text-gray-700 mb-2">Last Name</label>
                <input
                  type="text"
                  [(ngModel)]="form.lastName"
                  name="lastName"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-colors"
                  placeholder="Enter your last name"
                />
              </div>

              <!-- Email -->
              <div class="mb-8">
                <label class="block text-sm font-semibold text-gray-700 mb-2">Email ID</label>
                <input
                  type="email"
                  [(ngModel)]="form.email"
                  name="email"
                  required
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-colors"
                  placeholder="your@email.com"
                />
              </div>

              <!-- Submit Button -->
              <button
                type="submit"
                [disabled]="isLoading"
                class="w-full py-3 bg-gradient-to-r from-primary-600 to-primary-700 hover:from-primary-700 hover:to-primary-800 disabled:from-gray-400 disabled:to-gray-400 text-white font-bold rounded-lg transition-all transform hover:scale-105 disabled:hover:scale-100">
                {{ isLoading ? 'Logging in...' : 'Login' }}
              </button>
            </form>

            <!-- Sign Up Link -->
            <p class="text-center text-gray-600 mt-6">
              Don't have an account?
              <a routerLink="/signup" class="text-primary-600 hover:text-primary-700 font-semibold">
                Sign up here
              </a>
            </p>
          </div>
        </div>

        <!-- Info Box -->
        <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 class="font-bold text-blue-900 mb-2">Demo Login</h3>
          <p class="text-blue-800 text-sm mb-3">
            <strong>No password required!</strong> Simply enter your name and email to login.
          </p>
          <ul class="text-blue-700 text-sm space-y-1">
            <li>✓ Customer: Browse and rent films</li>
            <li>✓ Staff: Manage films and rentals</li>
          </ul>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class LoginComponent {
  activeTab: 'customer' | 'staff' = 'customer';
  form: LoginForm = {
    firstName: '',
    lastName: '',
    email: '',
  };
  errorMessage = '';
  isLoading = false;

  constructor(private roleService: RoleService, private router: Router) {}

  onLogin(): void {
    // Validate form
    if (!this.form.firstName.trim() || !this.form.lastName.trim() || !this.form.email.trim()) {
      this.errorMessage = 'Please fill in all fields';
      return;
    }

    // Simple email validation
    if (!this.form.email.includes('@')) {
      this.errorMessage = 'Please enter a valid email address';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    // Simulate backend validation delay
    setTimeout(() => {
      const role = this.activeTab === 'customer' ? UserRole.CUSTOMER : UserRole.STAFF;
      this.roleService.login({
        firstName: this.form.firstName,
        lastName: this.form.lastName,
        email: this.form.email,
        role: role,
      });

      this.isLoading = false;
      // Navigate based on role
      if (role === UserRole.CUSTOMER) {
        this.router.navigate(['/films']);
      } else {
        this.router.navigate(['/films']);
      }
    }, 500);
  }
}
