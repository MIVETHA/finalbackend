import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  STAFF = 'STAFF',
}

export interface CurrentUser {
  firstName: string;
  lastName: string;
  email: string;
  customerId?: number;
  staffId?: number;
  role: UserRole;
}

@Injectable({
  providedIn: 'root',
})
export class RoleService {
  private currentUserSubject = new BehaviorSubject<CurrentUser | null>(
    this.loadUserFromStorage()
  );
  public currentUser$ = this.currentUserSubject.asObservable();

  private roleSubject = new BehaviorSubject<UserRole | null>(
    this.getRoleFromStorage()
  );
  public role$ = this.roleSubject.asObservable();

  constructor() {}

  private loadUserFromStorage(): CurrentUser | null {
    try {
      const stored = localStorage.getItem('filmstore_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  }

  private getRoleFromStorage(): UserRole | null {
    try {
      const stored = localStorage.getItem('filmstore_role');
      return stored as UserRole | null;
    } catch {
      return null;
    }
  }

  login(user: CurrentUser): void {
    this.currentUserSubject.next(user);
    this.roleSubject.next(user.role);
    localStorage.setItem('filmstore_user', JSON.stringify(user));
    localStorage.setItem('filmstore_role', user.role);
  }

  logout(): void {
    this.currentUserSubject.next(null);
    this.roleSubject.next(null);
    localStorage.removeItem('filmstore_user');
    localStorage.removeItem('filmstore_role');
  }

  getCurrentUser(): CurrentUser | null {
    return this.currentUserSubject.value;
  }

  getCurrentRole(): UserRole | null {
    return this.roleSubject.value;
  }

  isLoggedIn(): boolean {
    return this.currentUserSubject.value !== null;
  }

  isCustomer(): boolean {
    return this.roleSubject.value === UserRole.CUSTOMER;
  }

  isStaff(): boolean {
    return this.roleSubject.value === UserRole.STAFF;
  }

  hasRole(role: UserRole): boolean {
    return this.roleSubject.value === role;
  }
}
