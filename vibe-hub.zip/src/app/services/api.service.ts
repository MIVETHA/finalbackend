import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

// Define API base URL - adjust as needed when backend URL is known
const API_BASE = 'http://localhost:8080/api';

export interface FilmDto {
  filmId: number;
  title: string;
  description?: string;
  releaseYear?: number;
  rentalRate: number;
  rentalDuration?: number;
  length?: number;
  replacementCost?: number;
  rating?: number;
  specialFeatures?: string;
  languageId: number;
  languageName?: string;
  lastUpdate?: string;
}

export interface ActorDto {
  id: number;
  firstName: string;
  lastName: string;
}

export interface CategoryDto {
  categoryId: number;
  name: string;
}

export interface LanguageDTO {
  languageId: number;
  name: string;
}

export interface CustomerDto {
  customerId: number;
  firstName: string;
  lastName: string;
  email: string;
  active: boolean;
  storeId?: number;
  addressId?: number;
}

export interface RentalDto {
  rentalId: number;
  rentalDate: string;
  returnDate?: string;
  customerId: number;
  inventoryId: number;
  staffId: number;
  lastUpdate: string;
}

export interface PaymentDTO {
  paymentId: number;
  customerId: number;
  rentalId: number;
  amount: number;
  paymentDate: string;
  lastUpdate: string;
}

export interface InventoryDTO {
  inventoryId: number;
  filmId: number;
  storeId: number;
  lastUpdate: string;
}

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) {}

  // Film endpoints
  getAllFilms(
    filters?: {
      actorId?: number;
      categoryId?: number;
      languageId?: number;
      minRating?: number;
      releaseYear?: number;
    }
  ): Observable<FilmDto[]> {
    let params = new HttpParams();
    if (filters) {
      if (filters.actorId) params = params.set('actorId', filters.actorId);
      if (filters.categoryId) params = params.set('categoryId', filters.categoryId);
      if (filters.languageId) params = params.set('languageId', filters.languageId);
      if (filters.minRating) params = params.set('minRating', filters.minRating);
      if (filters.releaseYear) params = params.set('releaseYear', filters.releaseYear);
    }
    return this.http.get<FilmDto[]>(`${API_BASE}/films`, { params });
  }

  getFilmById(id: number): Observable<FilmDto> {
    return this.http.get<FilmDto>(`${API_BASE}/films/${id}`);
  }

  createFilm(film: Partial<FilmDto>): Observable<FilmDto> {
    return this.http.post<FilmDto>(`${API_BASE}/films`, film);
  }

  updateFilm(id: number, film: Partial<FilmDto>): Observable<FilmDto> {
    return this.http.put<FilmDto>(`${API_BASE}/films/${id}`, film);
  }

  deleteFilm(id: number): Observable<void> {
    return this.http.delete<void>(`${API_BASE}/films/${id}`);
  }

  // Actor endpoints
  getAllActors(): Observable<ActorDto[]> {
    return this.http.get<ActorDto[]>(`${API_BASE}/actors`);
  }

  // Category endpoints
  getAllCategories(): Observable<CategoryDto[]> {
    return this.http.get<CategoryDto[]>(`${API_BASE}/categories`);
  }

  // Language endpoints
  getAllLanguages(): Observable<LanguageDTO[]> {
    return this.http.get<LanguageDTO[]>(`${API_BASE}/languages`);
  }

  // Customer endpoints
  createCustomer(customer: Partial<CustomerDto>): Observable<CustomerDto> {
    return this.http.post<CustomerDto>(`${API_BASE}/customers`, customer);
  }

  getCustomerById(id: number): Observable<CustomerDto> {
    return this.http.get<CustomerDto>(`${API_BASE}/customers/${id}`);
  }

  updateCustomer(id: number, customer: Partial<CustomerDto>): Observable<CustomerDto> {
    return this.http.put<CustomerDto>(`${API_BASE}/customers/${id}`, customer);
  }

  // Rental endpoints
  getAllRentals(): Observable<RentalDto[]> {
    return this.http.get<RentalDto[]>(`${API_BASE}/rentals`);
  }

  getRentalsByCustomerId(customerId: number): Observable<RentalDto[]> {
    return this.http.get<RentalDto[]>(`${API_BASE}/rentals/customer/${customerId}`);
  }

  createRental(rental: Partial<RentalDto>): Observable<RentalDto> {
    return this.http.post<RentalDto>(`${API_BASE}/rentals`, rental);
  }

  returnRental(rentalId: number): Observable<RentalDto> {
    return this.http.put<RentalDto>(`${API_BASE}/rentals/${rentalId}/return`, {});
  }

  // Payment endpoints
  getAllPayments(): Observable<PaymentDTO[]> {
    return this.http.get<PaymentDTO[]>(`${API_BASE}/payments`);
  }

  getPaymentsByCustomerId(customerId: number): Observable<PaymentDTO[]> {
    return this.http.get<PaymentDTO[]>(`${API_BASE}/payments/customer/${customerId}`);
  }

  createPayment(payment: Partial<PaymentDTO>): Observable<PaymentDTO> {
    return this.http.post<PaymentDTO>(`${API_BASE}/payments`, payment);
  }

  // Inventory endpoints
  getAllInventory(): Observable<InventoryDTO[]> {
    return this.http.get<InventoryDTO[]>(`${API_BASE}/inventory`);
  }

  getInventoryByFilmId(filmId: number): Observable<InventoryDTO[]> {
    return this.http.get<InventoryDTO[]>(`${API_BASE}/inventory/film/${filmId}`);
  }
}
