import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { RoleService, UserRole } from '../../services/role.service';
import { HasRoleDirective } from '../../directives/has-role.directive';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, HasRoleDirective],
  template: `
    <header class="bg-gradient-to-r from-primary-900 to-primary-800 text-white shadow-lg sticky top-0 z-50">
      <div class="max-w-7xl mx-auto px-4 py-4">
        <div class="flex justify-between items-center">
          <!-- Logo/Brand -->
          <div class="flex items-center gap-3">
            <div class="text-2xl font-bold flex items-center gap-2">
              <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54h2.88l2.96-3.83.63 4.63h2.96L17.5 6.5z"/>
              </svg>
              FilmRent
            </div>
          </div>

          <!-- Navigation Menu -->
          <nav class="hidden md:flex gap-1">
            <a routerLink="/" routerLinkActive="bg-primary-700" [routerLinkActiveOptions]="{ exact: true }"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
              Home
            </a>

            <!-- Customer Menu -->
            <div *appHasRole="'CUSTOMER'" class="flex gap-1">
              <a routerLink="/films" routerLinkActive="bg-primary-700"
                class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
                Films
              </a>
              <a routerLink="/rentals" routerLinkActive="bg-primary-700"
                class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
                My Rentals
              </a>
              <a routerLink="/payments" routerLinkActive="bg-primary-700"
                class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
                Payments
              </a>
            </div>

            <!-- Staff Menu -->
            <div *appHasRole="'STAFF'" class="flex gap-1">
              <a routerLink="/films" routerLinkActive="bg-primary-700"
                class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
                Films (Manage)
              </a>
              <a routerLink="/rentals" routerLinkActive="bg-primary-700"
                class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
                All Rentals
              </a>
              <a routerLink="/payments" routerLinkActive="bg-primary-700"
                class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700">
                All Payments
              </a>
            </div>
          </nav>

          <!-- User Section -->
          <div class="flex items-center gap-4">
            <!-- Current User Info -->
            <div *ngIf="currentUser$ | async as user" class="hidden sm:flex items-center gap-3">
              <div class="text-sm">
                <div class="font-semibold">{{ user.firstName }} {{ user.lastName }}</div>
                <div class="text-primary-200 text-xs">{{ user.role }}</div>
              </div>
            </div>

            <!-- Auth Buttons -->
            <div *ngIf="!(currentUser$ | async)" class="flex gap-2">
              <a routerLink="/login"
                class="px-4 py-2 bg-primary-700 hover:bg-primary-600 rounded-lg transition-colors font-medium">
                Login
              </a>
              <a routerLink="/signup"
                class="px-4 py-2 bg-accent-600 hover:bg-accent-500 rounded-lg transition-colors font-medium">
                Sign Up
              </a>
            </div>

            <!-- Logout Button -->
            <button *ngIf="currentUser$ | async" (click)="logout()"
              class="px-4 py-2 bg-red-600 hover:bg-red-500 rounded-lg transition-colors font-medium">
              Logout
            </button>
          </div>
        </div>

        <!-- Mobile Menu Button -->
        <button (click)="toggleMobileMenu()" class="md:hidden mt-2 text-sm underline">
          {{ mobileMenuOpen ? '✕ Close' : '☰ Menu' }}
        </button>

        <!-- Mobile Menu -->
        <nav *ngIf="mobileMenuOpen" class="md:hidden mt-4 flex flex-col gap-2">
          <a routerLink="/" (click)="mobileMenuOpen = false"
            class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
            Home
          </a>
          <div *appHasRole="'CUSTOMER'" class="flex flex-col gap-2">
            <a routerLink="/films" (click)="mobileMenuOpen = false"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
              Films
            </a>
            <a routerLink="/rentals" (click)="mobileMenuOpen = false"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
              My Rentals
            </a>
            <a routerLink="/payments" (click)="mobileMenuOpen = false"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
              Payments
            </a>
          </div>
          <div *appHasRole="'STAFF'" class="flex flex-col gap-2">
            <a routerLink="/films" (click)="mobileMenuOpen = false"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
              Films (Manage)
            </a>
            <a routerLink="/rentals" (click)="mobileMenuOpen = false"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
              All Rentals
            </a>
            <a routerLink="/payments" (click)="mobileMenuOpen = false"
              class="px-4 py-2 rounded-lg transition-colors hover:bg-primary-700 block">
              All Payments
            </a>
          </div>
        </nav>
      </div>
    </header>
  `,
  styles: [],
})
export class HeaderComponent implements OnInit {
  currentUser$!: Observable<any>;
  mobileMenuOpen = false;

  constructor(private roleService: RoleService, private router: Router) {}

  ngOnInit(): void {
    this.currentUser$ = this.roleService.currentUser$;
  }

  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
  }

  logout(): void {
    this.roleService.logout();
    this.router.navigate(['/']);
    this.mobileMenuOpen = false;
  }
}
