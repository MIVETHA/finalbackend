# Frontend Flow Documentation

## Application Architecture

### Directory Structure
```
src/
├── app/
│   ├── components/          # Shared UI components
│   │   ├── navbar.component.ts
│   │   ├── navbar.component.html
│   │   ├── navbar.component.scss
│   │   ├── footer.component.ts
│   │   ├── footer.component.html
│   │   └── footer.component.scss
│   ├── pages/               # Page components
│   │   ├── home.component.*
│   │   ├── login.component.*
│   │   ├── signup.component.*
│   │   ├── films.component.*
│   │   └── placeholder.component.*
│   ├── services/            # API services
│   │   ├── role.service.ts
│   │   ├── film.service.ts
│   │   ├── actor.service.ts
│   │   └── ...
│   ├── models/              # TypeScript interfaces
│   │   └── film.model.ts
│   ├── directives/          # Custom directives
│   │   └── has-role.directive.ts
│   ├── app.ts               # Root component
│   ├── app.html
│   ├── app.routes.ts        # Route definitions
│   └── app.config.ts        # App configuration
├── styles.css               # Global styles
└── main.ts                  # Bootstrap
```

## User Flows

### 1. Public User (Not Authenticated)
```
Home (/) → Browse Films (/films) → Film Details (/films/:id)
        ↓
     Login (/login) → [Customer Role Set]
        ↓
     Films (/films) → Rent Film → My Rentals (/rentals)
```

### 2. Customer Registration Flow
```
Home (/) → Sign Up (/signup) → Submit Form
                                ↓
                        Create Customer (API)
                                ↓
                        Auto-login as CUSTOMER
                                ↓
                        Redirect to /films
```

### 3. Customer Login Flow
```
Login (/login) → Customer Tab
              ↓
         Fill Form (First Name, Last Name, Email)
              ↓
         Set Role = CUSTOMER in RoleService
              ↓
         Navigate to /films
```

### 4. Staff Login Flow
```
Login (/login) → Staff Tab
             ↓
        Fill Form (First Name, Last Name, Email)
             ↓
        Set Role = STAFF in RoleService
             ↓
        Navigate to /films/manage
```

### 5. Films Browsing Flow (Customer)
```
Films (/films)
    ↓
  [Load all films from backend]
  [Load filter options: actors, categories, languages]
    ↓
  [User selects filters]
    ↓
  [Client-side filtering applied]
    ↓
  [Display matching films]
    ↓
  [Click "Rent Now" or "Details"]
```

## Component Relationships

### App Component (Root)
- Contains Navbar and Footer
- Uses RouterOutlet for page components
- Provides layout for all pages

### Navbar Component
- Shows different menus based on role
- Customer sees: Home, Films, My Rentals, Payments
- Staff sees: Home, Films (Manage), Inventory, Rentals
- Uses RoleService to determine visibility
- HasRoleDirective for conditional rendering

### RoleService
- Global state management for user role
- Stores user info in sessionStorage
- Methods:
  - `login()` - Set current user and role
  - `logout()` - Clear user data
  - `hasRole()` - Check if user has role
  - `getCurrentUser()` - Get current user info
  - `getCurrentRole()` - Get current role

### Films Component
- Loads films from FilmService
- Loads filter data from respective services
- Client-side filtering on loaded data
- **Note**: API has search endpoint, but client-side filtering used for flexibility

## Authentication & Authorization

### Authentication
- **No Backend Authentication**: Per requirements
- **No JWT/Sessions**: Credentials not stored
- **Frontend-Only**: User info stored in sessionStorage

### Authorization
- **Role-Based**: CUSTOMER or STAFF
- **Directive-Based**: `*appHasRole="'CUSTOMER'"`
- **No API Guards**: Backend assumes frontend handled it

## State Management

### Using Angular Signals
- RoleService uses signals for reactive state
- Components use `signal()` and `.asReadonly()` for immutability
- Form state managed with Reactive Forms (FormBuilder)

### Services
- Single service per domain (film, rental, payment, etc.)
- All API calls in services (not in components)
- Services are Injectable and providedIn 'root'

## Form Handling

### Login Form
- FormBuilder with validation
- Fields: firstName, lastName, email
- No password field per spec
- Sets role and navigates to appropriate page

### Signup Form
- FormBuilder with validation
- Fields: firstName, lastName, email, address, postalCode, phone
- Calls CustomerService.createCustomer()
- Auto-login on success

### Films Filter
- ngModel for two-way binding
- Real-time filtering as user changes filters
- Clear filters button resets all

## Styling Strategy

### Tailwind CSS
- Utility-first approach
- Custom colors in tailwind.config.js
- Dark theme (dark-900, dark-800, dark-700)
- Primary (cyan blue) and Accent (pink) colors

### Component Styles
- Separate .scss files for each component
- Global styles in styles.css
- Custom animations in tailwind.config.js

## Error Handling

### API Errors
- Try/catch with .subscribe() error handler
- Error messages displayed to user
- Console logging for debugging

### Form Validation
- HTML5 validators
- Custom validators for specific fields
- Error messages shown under invalid fields

## Performance Considerations

### Lazy Loading
- Placeholder pages not loaded until accessed
- Standalone components for tree-shaking

### Optimizations
- Signals for reactive updates
- OnPush change detection (when added)
- CSS animations with GPU acceleration

## Testing Checklist

- [ ] Home page loads correctly
- [ ] Navigation changes based on role
- [ ] Login sets correct role
- [ ] Sign up creates customer
- [ ] Films load from API
- [ ] Filters work correctly
- [ ] Logout clears session
- [ ] Responsive on mobile/tablet
