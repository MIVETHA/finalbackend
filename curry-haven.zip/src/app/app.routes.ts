import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home.component';
import { LoginComponent } from './pages/login.component';
import { SignupComponent } from './pages/signup.component';
import { FilmsComponent } from './pages/films.component';
import { PlaceholderComponent } from './pages/placeholder.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'films', component: FilmsComponent },
  { path: 'films/:id', component: PlaceholderComponent, data: { title: 'Film Details', description: 'View full details and rent this film', icon: '🎬' } },
  { path: 'films/manage', component: PlaceholderComponent, data: { title: 'Manage Films', description: 'Add, edit, and manage films (Staff Only)', icon: '⚙️' } },
  { path: 'inventory', component: PlaceholderComponent, data: { title: 'Inventory Management', description: 'Manage film inventory and stock (Staff Only)', icon: '📦' } },
  { path: 'rentals', component: PlaceholderComponent, data: { title: 'My Rentals', description: 'View and manage your rental history', icon: '📽️' } },
  { path: 'payment', component: PlaceholderComponent, data: { title: 'Payments', description: 'Process payments for your rentals', icon: '💳' } },
  { path: '**', redirectTo: '' }
];
