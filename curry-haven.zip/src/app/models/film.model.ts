export interface Film {
  filmId: number;
  title: string;
  description: string;
  releaseYear: number;
  languageId: number;
  rentalDuration: number;
  rentalRate: number;
  length: number;
  replacementCost: number;
  rating: string; // 'G', 'PG', 'PG-13', 'R', 'NC-17'
  specialFeatures: string;
  lastUpdate: Date;
  actors?: Actor[];
  categories?: Category[];
  language?: Language;
  inventories?: Inventory[];
}

export interface Actor {
  actorId: number;
  firstName: string;
  lastName: string;
  lastUpdate: Date;
  films?: Film[];
}

export interface Category {
  categoryId: number;
  name: string;
  lastUpdate: Date;
  films?: Film[];
}

export interface Language {
  languageId: number;
  name: string;
  lastUpdate: Date;
  films?: Film[];
}

export interface Customer {
  customerId: number;
  firstName: string;
  lastName: string;
  email: string;
  addressId: number;
  createDate: Date;
  lastUpdate: Date;
  address?: Address;
  rentals?: Rental[];
}

export interface Address {
  addressId: number;
  address: string;
  address2?: string;
  district: string;
  cityId: number;
  postalCode: string;
  phone: string;
  lastUpdate: Date;
  city?: City;
  customers?: Customer[];
}

export interface City {
  cityId: number;
  city: string;
  countryId: number;
  lastUpdate: Date;
  country?: Country;
  addresses?: Address[];
}

export interface Country {
  countryId: number;
  country: string;
  lastUpdate: Date;
  cities?: City[];
}

export interface Rental {
  rentalId: number;
  rentalDate: Date;
  inventoryId: number;
  customerId: number;
  returnDate?: Date;
  lastUpdate: Date;
  inventory?: Inventory;
  customer?: Customer;
  payments?: Payment[];
}

export interface Inventory {
  inventoryId: number;
  filmId: number;
  storeId: number;
  lastUpdate: Date;
  film?: Film;
  store?: Store;
  rentals?: Rental[];
}

export interface Store {
  storeId: number;
  addressId: number;
  lastUpdate: Date;
  address?: Address;
  inventories?: Inventory[];
  staff?: Staff[];
}

export interface Payment {
  paymentId: number;
  customerId: number;
  staffId: number;
  rentalId: number;
  amount: number;
  paymentDate: Date;
  lastUpdate: Date;
  customer?: Customer;
  rental?: Rental;
  staff?: Staff;
}

export interface Staff {
  staffId: number;
  firstName: string;
  lastName: string;
  addressId: number;
  email: string;
  storeId: number;
  active: boolean;
  username: string;
  password: string;
  lastUpdate: Date;
  address?: Address;
  store?: Store;
}

export interface User {
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
}

export type UserRole = 'CUSTOMER' | 'STAFF';

// DTOs for API requests/responses
export interface FilmDto {
  filmId?: number;
  title: string;
  description: string;
  releaseYear: number;
  languageId: number;
  rentalDuration: number;
  rentalRate: number;
  length: number;
  replacementCost: number;
  rating: string;
  specialFeatures?: string;
}

export interface CustomerDto {
  customerId?: number;
  firstName: string;
  lastName: string;
  email: string;
  addressId: number;
}

export interface RentalDto {
  rentalId?: number;
  rentalDate: Date;
  inventoryId: number;
  customerId: number;
  returnDate?: Date;
}

export interface PaymentDto {
  paymentId?: number;
  customerId: number;
  staffId: number;
  rentalId: number;
  amount: number;
  paymentDate: Date;
}
