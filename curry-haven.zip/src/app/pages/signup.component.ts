import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CustomerService } from '../services/customer.service';
import { RoleService } from '../services/role.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.scss'
})
export class SignupComponent {
  signupForm: FormGroup;
  isLoading = signal(false);
  errorMessage = signal('');
  successMessage = signal('');

  constructor(
    private fb: FormBuilder,
    private customerService: CustomerService,
    private roleService: RoleService,
    private router: Router
  ) {
    this.signupForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      address: ['', [Validators.required, Validators.minLength(5)]],
      postalCode: ['', [Validators.required]],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9\-\+\(\)\s]{7,}$/)]]
    });
  }

  signup(): void {
    if (this.signupForm.invalid) {
      this.errorMessage.set('Please fill in all fields correctly');
      return;
    }

    this.isLoading.set(true);
    this.errorMessage.set('');

    const formValue = this.signupForm.value;

    // Call backend API to create customer
    // Note: addressId would need to be handled in a real scenario
    const customerDto = {
      firstName: formValue.firstName,
      lastName: formValue.lastName,
      email: formValue.email,
      addressId: 1 // Placeholder - would need proper address creation flow
    };

    this.customerService.createCustomer(customerDto).subscribe({
      next: (response) => {
        this.isLoading.set(false);
        this.successMessage.set('Account created successfully! Logging you in...');
        
        // Auto-login
        setTimeout(() => {
          this.roleService.login(
            formValue.firstName,
            formValue.lastName,
            formValue.email,
            'CUSTOMER'
          );
          this.router.navigate(['/films']);
        }, 1500);
      },
      error: (error) => {
        this.isLoading.set(false);
        this.errorMessage.set(error.error?.message || 'Failed to create account. Please try again.');
        console.error('Signup error:', error);
      }
    });
  }

  getErrorMessage(field: string): string {
    const control = this.signupForm.get(field);
    if (!control || !control.errors) return '';

    if (control.errors['required']) return `${this.formatFieldName(field)} is required`;
    if (control.errors['minlength']) {
      const minLength = control.errors['minlength'].requiredLength;
      return `${this.formatFieldName(field)} must be at least ${minLength} characters`;
    }
    if (control.errors['email']) return 'Please enter a valid email address';
    if (control.errors['pattern']) return 'Please enter a valid phone number';
    return '';
  }

  private formatFieldName(field: string): string {
    return field.replace(/([A-Z])/g, ' $1').trim()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
}
