import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Film, FilmDto } from '../models/film.model';

@Injectable({
  providedIn: 'root'
})
export class FilmService {
  private apiUrl = 'http://localhost:8080/api/films';

  constructor(private http: HttpClient) { }

  getAllFilms(): Observable<Film[]> {
    return this.http.get<Film[]>(this.apiUrl);
  }

  getFilmById(id: number): Observable<Film> {
    return this.http.get<Film>(`${this.apiUrl}/${id}`);
  }

  createFilm(film: FilmDto): Observable<Film> {
    return this.http.post<Film>(this.apiUrl, film);
  }

  updateFilm(id: number, film: FilmDto): Observable<Film> {
    return this.http.put<Film>(`${this.apiUrl}/${id}`, film);
  }

  deleteFilm(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  searchFilms(params: {
    actorId?: number;
    categoryId?: number;
    languageId?: number;
    rating?: string;
    releaseYear?: number;
    maxPrice?: number;
  }): Observable<Film[]> {
    let httpParams = new HttpParams();
    
    if (params.actorId) httpParams = httpParams.set('actorId', params.actorId.toString());
    if (params.categoryId) httpParams = httpParams.set('categoryId', params.categoryId.toString());
    if (params.languageId) httpParams = httpParams.set('languageId', params.languageId.toString());
    if (params.rating) httpParams = httpParams.set('rating', params.rating);
    if (params.releaseYear) httpParams = httpParams.set('releaseYear', params.releaseYear.toString());
    if (params.maxPrice) httpParams = httpParams.set('maxPrice', params.maxPrice.toString());

    return this.http.get<Film[]>(`${this.apiUrl}/search`, { params: httpParams });
  }
}
