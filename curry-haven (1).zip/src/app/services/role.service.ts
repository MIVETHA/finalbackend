import { Injectable, signal } from '@angular/core';
import { User, UserRole } from '../models/film.model';

@Injectable({
  providedIn: 'root'
})
export class RoleService {
  currentUser = signal<User | null>(null);
  currentRole = signal<UserRole | null>(null);
  isAuthenticated = signal(false);

  constructor() {
    this.loadUserFromSessionStorage();
  }

  login(firstName: string, lastName: string, email: string, role: UserRole): void {
    const user: User = {
      firstName,
      lastName,
      email,
      role
    };
    this.currentUser.set(user);
    this.currentRole.set(role);
    this.isAuthenticated.set(true);
    this.saveUserToSessionStorage(user);
  }

  logout(): void {
    this.currentUser.set(null);
    this.currentRole.set(null);
    this.isAuthenticated.set(false);
    sessionStorage.removeItem('filmRentalUser');
  }

  hasRole(role: UserRole): boolean {
    return this.currentRole() === role;
  }

  isCustomer(): boolean {
    return this.currentRole() === 'CUSTOMER';
  }

  isStaff(): boolean {
    return this.currentRole() === 'STAFF';
  }

  getCurrentUser(): User | null {
    return this.currentUser();
  }

  getCurrentRole(): UserRole | null {
    return this.currentRole();
  }

  private saveUserToSessionStorage(user: User): void {
    sessionStorage.setItem('filmRentalUser', JSON.stringify(user));
  }

  private loadUserFromSessionStorage(): void {
    const user = sessionStorage.getItem('filmRentalUser');
    if (user) {
      try {
        const parsedUser: User = JSON.parse(user);
        this.currentUser.set(parsedUser);
        this.currentRole.set(parsedUser.role);
        this.isAuthenticated.set(true);
      } catch (e) {
        console.error('Failed to parse user from storage:', e);
      }
    }
  }
}
