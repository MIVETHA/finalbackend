import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Film, Actor, Category, Language } from '../models/film.model';
import { FilmService } from '../services/film.service';
import { ActorService } from '../services/actor.service';
import { CategoryService } from '../services/category.service';
import { LanguageService } from '../services/language.service';

@Component({
  selector: 'app-films',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './films.component.html',
  styleUrl: './films.component.scss'
})
export class FilmsComponent implements OnInit {
  films = signal<Film[]>([]);
  filteredFilms = signal<Film[]>([]);
  actors = signal<Actor[]>([]);
  categories = signal<Category[]>([]);
  languages = signal<Language[]>([]);

  isLoading = signal(true);
  error = signal('');

  // Filter values
  searchTerm = signal('');
  selectedActorId = signal<number | null>(null);
  selectedCategoryId = signal<number | null>(null);
  selectedLanguageId = signal<number | null>(null);
  selectedRating = signal<string>('');
  selectedYear = signal<number | null>(null);
  maxPrice = signal<number | null>(null);

  // Available ratings
  ratings = ['G', 'PG', 'PG-13', 'R', 'NC-17'];
  years: number[] = [];

  constructor(
    private filmService: FilmService,
    private actorService: ActorService,
    private categoryService: CategoryService,
    private languageService: LanguageService
  ) {
    this.generateYears();
  }

  ngOnInit(): void {
    this.loadFilms();
    this.loadFilters();
  }

  private loadFilms(): void {
    this.isLoading.set(true);
    this.error.set('');

    this.filmService.getAllFilms().subscribe({
      next: (data) => {
        this.films.set(data);
        this.applyFilters();
        this.isLoading.set(false);
      },
      error: (err) => {
        this.error.set('Failed to load films. Please try again.');
        console.error('Error loading films:', err);
        this.isLoading.set(false);
      }
    });
  }

  private loadFilters(): void {
    // Load actors
    this.actorService.getAllActors().subscribe({
      next: (data) => this.actors.set(data),
      error: (err) => console.error('Error loading actors:', err)
    });

    // Load categories
    this.categoryService.getAllCategories().subscribe({
      next: (data) => this.categories.set(data),
      error: (err) => console.error('Error loading categories:', err)
    });

    // Load languages
    this.languageService.getAllLanguages().subscribe({
      next: (data) => this.languages.set(data),
      error: (err) => console.error('Error loading languages:', err)
    });
  }

  applyFilters(): void {
    let result = [...this.films()];

    // Search by title or description
    if (this.searchTerm()) {
      const term = this.searchTerm().toLowerCase();
      result = result.filter(film =>
        film.title.toLowerCase().includes(term) ||
        film.description.toLowerCase().includes(term)
      );
    }

    // Filter by actor
    if (this.selectedActorId()) {
      result = result.filter(film =>
        film.actors?.some(a => a.actorId === this.selectedActorId())
      );
    }

    // Filter by category
    if (this.selectedCategoryId()) {
      result = result.filter(film =>
        film.categories?.some(c => c.categoryId === this.selectedCategoryId())
      );
    }

    // Filter by language
    if (this.selectedLanguageId()) {
      result = result.filter(film =>
        film.languageId === this.selectedLanguageId()
      );
    }

    // Filter by rating
    if (this.selectedRating()) {
      result = result.filter(film =>
        film.rating === this.selectedRating()
      );
    }

    // Filter by release year
    if (this.selectedYear()) {
      result = result.filter(film =>
        film.releaseYear === this.selectedYear()
      );
    }

    // Filter by max price
    if (this.maxPrice()) {
      result = result.filter(film =>
        film.rentalRate <= this.maxPrice()!
      );
    }

    this.filteredFilms.set(result);
  }

  clearFilters(): void {
    this.searchTerm.set('');
    this.selectedActorId.set(null);
    this.selectedCategoryId.set(null);
    this.selectedLanguageId.set(null);
    this.selectedRating.set('');
    this.selectedYear.set(null);
    this.maxPrice.set(null);
    this.applyFilters();
  }

  private generateYears(): void {
    const currentYear = new Date().getFullYear();
    for (let i = currentYear; i >= 1900; i--) {
      this.years.push(i);
    }
  }

  getRatingColor(rating: string): string {
    switch (rating) {
      case 'G': return 'bg-green-600';
      case 'PG': return 'bg-blue-600';
      case 'PG-13': return 'bg-yellow-600';
      case 'R': return 'bg-red-600';
      case 'NC-17': return 'bg-red-900';
      default: return 'bg-gray-600';
    }
  }
}
