import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RoleService } from '../services/role.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  activeTab = signal<'customer' | 'staff'>('customer');
  customerForm: FormGroup;
  staffForm: FormGroup;
  isLoading = signal(false);
  errorMessage = signal('');

  constructor(
    private fb: FormBuilder,
    private roleService: RoleService,
    private router: Router
  ) {
    this.customerForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]]
    });

    this.staffForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  switchTab(tab: 'customer' | 'staff'): void {
    this.activeTab.set(tab);
    this.errorMessage.set('');
  }

  loginAsCustomer(): void {
    if (this.customerForm.invalid) {
      this.errorMessage.set('Please fill in all fields correctly');
      return;
    }

    this.isLoading.set(true);
    const { firstName, lastName, email } = this.customerForm.value;

    // Simulate API call delay
    setTimeout(() => {
      this.roleService.login(firstName, lastName, email, 'CUSTOMER');
      this.isLoading.set(false);
      this.router.navigate(['/films']);
    }, 500);
  }

  loginAsStaff(): void {
    if (this.staffForm.invalid) {
      this.errorMessage.set('Please fill in all fields correctly');
      return;
    }

    this.isLoading.set(true);
    const { firstName, lastName, email } = this.staffForm.value;

    // Simulate API call delay
    setTimeout(() => {
      this.roleService.login(firstName, lastName, email, 'STAFF');
      this.isLoading.set(false);
      this.router.navigate(['/films/manage']);
    }, 500);
  }

  getCustomerErrorMessage(field: string): string {
    const control = this.customerForm.get(field);
    if (!control || !control.errors) return '';

    if (control.errors['required']) return `${this.formatFieldName(field)} is required`;
    if (control.errors['minlength']) return `${this.formatFieldName(field)} must be at least 2 characters`;
    if (control.errors['email']) return 'Please enter a valid email address';
    return '';
  }

  getStaffErrorMessage(field: string): string {
    const control = this.staffForm.get(field);
    if (!control || !control.errors) return '';

    if (control.errors['required']) return `${this.formatFieldName(field)} is required`;
    if (control.errors['minlength']) return `${this.formatFieldName(field)} must be at least 2 characters`;
    if (control.errors['email']) return 'Please enter a valid email address';
    return '';
  }

  private formatFieldName(field: string): string {
    return field.replace(/([A-Z])/g, ' $1').trim()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
}
