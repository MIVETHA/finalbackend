import { Directive, Input, TemplateRef, ViewContainerRef, OnInit, effect } from '@angular/core';
import { RoleService } from '../services/role.service';
import { UserRole } from '../models/film.model';

@Directive({
  selector: '[appHasRole]',
  standalone: true
})
export class HasRoleDirective implements OnInit {
  private role!: UserRole;

  @Input()
  set appHasRole(role: UserRole) {
    this.role = role;
    this.updateView();
  }

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private roleService: RoleService
  ) {
    // Watch for role changes
    effect(() => {
      this.roleService.currentRole();
      this.updateView();
    });
  }

  ngOnInit(): void {
    this.updateView();
  }

  private updateView(): void {
    if (this.roleService.hasRole(this.role)) {
      this.viewContainer.clear();
      this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }
}
