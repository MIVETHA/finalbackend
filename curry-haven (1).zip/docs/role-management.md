# Role Management Documentation

## Overview
Role management is handled entirely on the frontend. The application supports two roles:
1. **CUSTOMER** - Regular users who rent films
2. **STAFF** - Employees who manage films, inventory, and rentals

## RoleService

### Location
`src/app/services/role.service.ts`

### Signals (Reactive State)
```typescript
currentUser$ = this.currentUser.asReadonly();      // Current logged-in user
currentRole$ = this.currentRole.asReadonly();      // Current role (CUSTOMER | STAFF)
isAuthenticated$ = this.isAuthenticated.asReadonly(); // Auth state
```

### Key Methods

#### login(firstName, lastName, email, role)
Sets the current user and role in the application
```typescript
this.roleService.login('John', 'Doe', 'john@example.com', 'CUSTOMER');
```
- Saves to sessionStorage for persistence across page refreshes
- Sets all three signals

#### logout()
Clears user data and signs out
```typescript
this.roleService.logout();
```
- Removes from sessionStorage
- Clears all signals
- Called on logout button click

#### hasRole(role)
Check if current user has specific role
```typescript
if (this.roleService.hasRole('CUSTOMER')) {
  // Show customer features
}
```
- Returns boolean
- Used in conditional rendering

#### isCustomer() / isStaff()
Convenience methods for role checking
```typescript
if (this.roleService.isCustomer()) {
  // Customer-specific logic
}
```

#### getCurrentUser() / getCurrentRole()
Get current user/role directly
```typescript
const user = this.roleService.getCurrentUser();
const role = this.roleService.getCurrentRole();
```

## HasRole Directive

### Location
`src/app/directives/has-role.directive.ts`

### Usage
Conditionally show/hide elements based on role
```html
<a *appHasRole="'CUSTOMER'" routerLink="/rentals">My Rentals</a>
<a *appHasRole="'STAFF'" routerLink="/films/manage">Manage Films</a>
```

### Implementation
- Structural directive using `*`
- Adds/removes element from DOM based on role
- Updates automatically when role changes
- Unsubscribes on component destroy

## Navigation Based on Role

### Customer Menu (from Navbar)
```
Home
Films
My Rentals (CUSTOMER only)
Payments (CUSTOMER only)
```

### Staff Menu (from Navbar)
```
Home
Films
Manage Films (STAFF only)
Inventory (STAFF only)
```

## Page Access Control

### Public Pages
- Home (`/`)
- Login (`/login`)
- Sign Up (`/signup`)

### Customer Pages
- Films (`/films`)
- Film Details (`/films/:id`)
- My Rentals (`/rentals`)
- Payments (`/payment`)

### Staff Pages
- Films (`/films`) - Can see all films
- Manage Films (`/films/manage`)
- Inventory (`/inventory`)

**Note**: No route guards implemented per requirements. Frontend only shows/hides UI based on role. Backend should implement guards.

## Login Flow with Roles

### Customer Login
```typescript
// User fills form: firstName, lastName, email
// Component calls:
this.roleService.login(firstName, lastName, email, 'CUSTOMER');
this.router.navigate(['/films']);
```

### Staff Login
```typescript
// User fills form: firstName, lastName, email
// Component calls:
this.roleService.login(firstName, lastName, email, 'STAFF');
this.router.navigate(['/films/manage']);
```

### Sign Up (Always Creates CUSTOMER)
```typescript
// User fills signup form
// Service creates customer in database
// Auto-login as CUSTOMER:
this.roleService.login(firstName, lastName, email, 'CUSTOMER');
```

## Session Persistence

### SessionStorage
User data persisted in browser sessionStorage:
```typescript
sessionStorage.setItem('filmRentalUser', JSON.stringify(user));
```

### On App Load
RoleService constructor loads user from sessionStorage:
```typescript
ngOnInit() {
  const user = sessionStorage.getItem('filmRentalUser');
  if (user) {
    this.currentUser.set(JSON.parse(user));
    this.currentRole.set(user.role);
    this.isAuthenticated.set(true);
  }
}
```

### Benefits
- User stays logged in after page refresh
- No server-side session needed
- Lost on browser close (sessionStorage)

## Using Role Information in Components

### Checking Role
```typescript
constructor(private roleService: RoleService) {
  this.isStaff = this.roleService.isStaff();
}
```

### Watching Role Changes
```typescript
this.roleService.currentRole$.subscribe((role) => {
  console.log('Role changed to:', role);
});
```

### In Templates
```html
<!-- Using pipe -->
<span>{{ (roleService.currentRole$ | async) }}</span>

<!-- Using directive -->
<div *appHasRole="'CUSTOMER'">
  Customer content
</div>
```

## Testing Roles

### Simulate Customer Login
1. Go to `/login`
2. Select "Customer" tab
3. Fill form: John, Doe, john@example.com
4. Click "Sign In as Customer"
5. Should redirect to `/films`
6. Navbar should show: Home, Films, My Rentals, Payments

### Simulate Staff Login
1. Go to `/login`
2. Select "Staff" tab
3. Fill form: Jane, Smith, jane@example.com
4. Click "Sign In as Staff"
5. Should redirect to `/films/manage`
6. Navbar should show: Home, Films, Manage Films, Inventory

### Logout
1. Click "Logout" in navbar
2. Should redirect to home
3. Navbar should show login/signup buttons

## Future Enhancements

### To Add Authentication:
1. Create auth interceptor
2. Add JWT token storage
3. Implement route guards
4. Add login API endpoint
5. Add refresh token logic

### To Add Permissions:
1. Extend role system to permissions
2. Implement permission checks
3. Add more granular access control

### To Add Multi-Store Support:
1. Add store selection
2. Filter data by store
3. Extend role with store ID
