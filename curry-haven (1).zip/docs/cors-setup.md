# CORS Setup Guide

## Overview

Cross-Origin Resource Sharing (CORS) allows the frontend application running on `http://localhost:4200` to make API requests to the backend running on `http://localhost:8080`.

## Backend Configuration (Spring Boot)

### Using WebMvcConfigurer

Create a configuration class in your Spring Boot application:

```java
package com.example.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins("http://localhost:4200")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                .allowedHeaders("*")
                .exposedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
```

### Using @CrossOrigin Annotation

Alternatively, annotate your controllers:

```java
@RestController
@RequestMapping("/api/films")
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
public class FilmController {
    // Methods
}
```

### Using application.properties

For global CORS configuration in application.properties:

```properties
# CORS Configuration
server.servlet.context-path=/
spring.web.cors.allowed-origins=http://localhost:4200
spring.web.cors.allowed-methods=GET,POST,PUT,DELETE,PATCH,OPTIONS
spring.web.cors.allowed-headers=*
spring.web.cors.exposed-headers=*
spring.web.cors.allow-credentials=true
spring.web.cors.max-age=3600
```

**Note**: This approach may not work with Spring Boot 3.x. Use `WebMvcConfigurer` instead.

## Frontend Configuration (Angular)

### HttpClient in Angular

The Angular HttpClient automatically includes required CORS headers:

```typescript
import { HttpClient } from '@angular/common/http';

constructor(private http: HttpClient) {}

getAllFilms(): Observable<Film[]> {
  return this.http.get<Film[]>('http://localhost:8080/api/films');
}
```

### Proxy Configuration (Development)

For development, you can use Angular's proxy feature instead of CORS:

Create `proxy.conf.json`:

```json
{
  "/api": {
    "target": "http://localhost:8080",
    "secure": false,
    "pathRewrite": {
      "^/api": "/api"
    }
  }
}
```

Update `angular.json`:

```json
{
  "serve": {
    "options": {
      "proxyConfig": "proxy.conf.json"
    }
  }
}
```

Then in services, use relative URLs:

```typescript
getAllFilms(): Observable<Film[]> {
  return this.http.get<Film[]>('/api/films');
}
```

## Frontend Service Configuration

### Current Configuration

All services use absolute URLs pointing to `http://localhost:8080/api`:

```typescript
private apiUrl = 'http://localhost:8080/api/films';
```

### Production Configuration

For production, update API URLs to relative paths or environment-based URLs:

Create `environment.prod.ts`:

```typescript
export const environment = {
  production: true,
  apiUrl: 'https://yourdomain.com/api'
};
```

Create `environment.ts`:

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api'
};
```

Update services:

```typescript
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class FilmService {
  private apiUrl = `${environment.apiUrl}/films`;
}
```

## Troubleshooting CORS Issues

### Error: "Access to XMLHttpRequest denied by CORS policy"

**Causes:**
1. Backend CORS not configured
2. Origin not in allowedOrigins
3. Method not in allowedMethods
4. Required headers not in allowedHeaders

**Solutions:**
1. Check backend CORS configuration
2. Verify frontend URL matches allowedOrigins
3. Add method to allowedMethods (GET, POST, PUT, DELETE, PATCH)
4. Allow all headers with `allowedHeaders("*")`

### Preflight Request Failures

**What happens:**
1. Browser sends OPTIONS request first
2. Backend must respond with CORS headers
3. Browser then sends actual request

**Solutions:**
1. Include `OPTIONS` in allowedMethods
2. Set `maxAge` to cache preflight responses
3. Check server is running and responding

### Credentials Not Sent

**Issue:**
Cookies or authorization headers not sent with requests

**Solution:**
Enable credentials in both backend and frontend:

Backend:
```java
registry.addMapping("/api/**")
        .allowCredentials(true);
```

Frontend:
```typescript
return this.http.get<Film[]>(url, {
  withCredentials: true
});
```

## Testing CORS

### Using curl

```bash
# Preflight request
curl -X OPTIONS http://localhost:8080/api/films \
  -H "Origin: http://localhost:4200" \
  -H "Access-Control-Request-Method: GET" \
  -v

# Actual request
curl -X GET http://localhost:8080/api/films \
  -H "Origin: http://localhost:4200" \
  -v
```

### Using Browser Console

```javascript
fetch('http://localhost:8080/api/films')
  .then(r => r.json())
  .then(d => console.log(d))
  .catch(e => console.error(e));
```

### Using Postman

1. Set request method (GET, POST, etc.)
2. Set URL: `http://localhost:8080/api/films`
3. Headers:
   - Origin: `http://localhost:4200`
   - Content-Type: `application/json` (for POST/PUT)
4. Send request
5. Check response headers for CORS headers

## Production Deployment

### Important Considerations

1. **Update CORS Origins**
   - Use actual domain instead of localhost
   - Use HTTPS in production
   - No wildcard `*` for security

2. **Environment-Specific URLs**
   - Use relative URLs or environment variables
   - Different APIs for dev/staging/production

3. **API Versioning**
   - Include version in URL: `/api/v1/films`
   - Easier for backwards compatibility

4. **Rate Limiting**
   - Implement on backend
   - Prevent abuse

5. **Authentication**
   - Implement OAuth2/JWT
   - Secure API endpoints
   - Validate tokens on backend

### Example Production CORS

```java
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value("${cors.allowed-origins}")
    private String allowedOrigins;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(allowedOrigins.split(","))
                .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH")
                .allowedHeaders("Content-Type", "Authorization")
                .exposedHeaders("X-Total-Count")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
```

application-prod.properties:
```properties
cors.allowed-origins=https://yourdomain.com
```

## References

- [MDN: CORS](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS)
- [Spring Boot CORS](https://spring.io/blog/2015/06/08/cors-support-in-spring-framework)
- [Angular HTTP Client](https://angular.io/guide/http)
