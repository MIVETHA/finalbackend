# UI Design Documentation

## Design System

### Color Palette

#### Primary Colors
- **Primary-500**: `#0ea5e9` (Cyan Blue) - Main action color
- **Primary-600**: `#0284c7` - Hover state
- **Primary-700**: `#0369a1` - Active state
- Shades: 50, 100, 200, 300, 400, 800, 900

#### Accent Colors
- **Accent-500**: `#ec4899` (Pink) - Secondary action
- **Accent-600**: `#db2777` - Hover state
- **Accent-700**: `#be185d` - Active state
- Shades: 50, 100, 200, 300, 400, 800, 900

#### Neutral Colors
- **Dark-900**: `#111827` - Background
- **Dark-800**: `#1f2937` - Cards, modals
- **Dark-700**: `#374151` - Borders, secondary bg
- **Dark-600**: `#4b5563` - Disabled
- White: `#ffffff` - Text on dark

### Typography

#### Font Stack
```css
sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif']
display: ['Poppins', 'system-ui', 'sans-serif']
```

#### Font Sizes
- **xs**: 0.75rem (12px)
- **sm**: 0.875rem (14px)
- **base**: 1rem (16px)
- **lg**: 1.125rem (18px)
- **xl**: 1.25rem (20px)
- **2xl**: 1.5rem (24px)
- **3xl**: 1.875rem (30px)
- **4xl**: 2.25rem (36px)
- **5xl**: 3rem (48px)

#### Font Weights
- Regular: 400
- Medium: 500
- Semibold: 600
- Bold: 700
- Display Bold: 700

### Spacing

Standard spacing scale (4px base):
- xs: 0.25rem (4px)
- sm: 0.5rem (8px)
- md: 1rem (16px)
- lg: 1.5rem (24px)
- xl: 2rem (32px)
- 2xl: 3rem (48px)
- 3xl: 4rem (64px)

### Border Radius

- sm: 0.375rem (6px)
- md: 0.5rem (8px)
- lg: 1rem (16px)
- xl: 1.5rem (24px)
- 2xl: 2rem (32px) - Cards, modals
- 2.5xl: 1.25rem (20px)
- full: 9999px - Pills, circles

### Shadows

#### Box Shadows
- **sm**: Light elevation
- **md**: Medium elevation
- **lg**: Card elevation
- **xl**: Modal elevation
- **film**: Cinema-specific shadow (primary glow)

#### Hover Effects
- Scale: 1.05 (5% increase)
- Shadow: Increases on hover
- Color: Transitions to primary/accent

### Animations

#### Transitions
- Default duration: 300ms
- Easing: ease, ease-in, ease-out

#### Keyframe Animations
- **fade-in**: 0 → 100% opacity (500ms)
- **slide-up**: Translate Y + fade (500ms)
- **pulse-soft**: Gentle opacity pulse (2s)
- **bounce**: Bootstrap bounce animation

### Layout System

#### Container
- Max-width: 1280px (7xl)
- Padding: 1rem - 2rem (responsive)
- Responsive: xs, sm, md, lg, xl

#### Grid
- Primary: 12-column grid
- Gap: 1rem - 2rem (responsive)
- Breakpoints:
  - sm: 640px
  - md: 768px
  - lg: 1024px
  - xl: 1280px

## Component Guidelines

### Cards
```
border: 1px solid dark-700
bg: dark-800 at 40-50% opacity
backdrop: blur-sm
border-radius: 1rem (16px)
padding: 1.5rem
hover: border-primary-500, shadow-lg
transition: all 300ms
```

### Buttons
- **Primary**: Gradient bg-primary → hover darker
- **Secondary**: Border + text color
- **Disabled**: opacity-50, cursor-not-allowed
- **Size**: py-3 px-6 (standard)
- **Hover**: scale-105, shadow increase
- **Rounded**: 0.5rem - 1rem

### Input Fields
```
bg: dark-700
border: 1px solid dark-600
border-radius: 0.5rem
padding: 0.75rem 1rem
focus: border-primary-500, box-shadow (primary glow)
error: border-red-500
transition: all 300ms
```

### Navigation
- **Navbar**: 
  - Fixed top, z-50
  - bg-dark-900, shadow-lg
  - height: 4rem (64px)
  - Sticky position on mobile
  
- **Links**:
  - Text color: gray-200
  - Hover: primary-400
  - Active: Underline gradient
  - Smooth transition

### Hero Section
- Full viewport height or 600px min
- Gradient background
- Animated blobs in background
- Centered content
- CTA buttons prominent

### Film Card
- Height: 380px
- Poster area: 288px height
- Content area: Scrollable if needed
- Hover: 
  - Scale up 1.05
  - Shadow highlight
  - Border glow
- Rating badge: Top-right corner

### Forms
- Space between fields: 1.25rem
- Labels: 0.875rem, medium, text-gray-300
- Inputs: Full width, responsive
- Error text: 0.875rem, text-red-400
- Submit: Full width, prominent color

## Responsive Design

### Mobile (< 640px)
- Single column layouts
- Hamburger menu for nav
- Full-width cards
- Larger touch targets (min 44px)
- Stack elements vertically

### Tablet (640px - 1024px)
- 2-3 column layouts
- Sidebar becomes visible
- Adjust padding/margins
- Medium touch targets

### Desktop (> 1024px)
- Full layouts (3-4 columns)
- Sidebars fixed
- Optimal reading width
- Hover states active

## Accessibility

### Color Contrast
- Text on dark: WCAG AA compliant
- Buttons: Sufficient contrast
- Form labels: Distinct colors

### Touch Targets
- Minimum 44x44px for buttons
- Sufficient spacing between clickables
- Larger on mobile

### Keyboard Navigation
- Tab order logical
- Focus visible outlines
- Keyboard shortcuts helpful

### Screen Readers
- Semantic HTML
- ARIA labels where needed
- Form labels associated
- Image alt text

## Dark Theme Implementation

### Background
- Base: dark-900 (#111827)
- Elevated: dark-800 (#1f2937)
- Secondary: dark-700 (#374151)
- Borders: dark-700 (#374151)

### Text
- Primary: white (#ffffff)
- Secondary: gray-300 (#d1d5db)
- Tertiary: gray-400 (#9ca3af)
- Disabled: gray-500 (#6b7280)

### Accents
- Primary highlight: primary-400 (#38bdf8)
- Secondary highlight: accent-400 (#f472b6)
- Success: green-400 (#4ade80)
- Warning: yellow-400 (#facc15)
- Error: red-400 (#f87171)

## Interaction Patterns

### Loading States
- Spinner animation (spin)
- Loading text changes
- Button disabled during load
- Skeleton screens optional

### Error States
- Red border around input
- Error text below field
- Error toast/modal
- Helpful error messages

### Success States
- Green indicator
- Success message
- Toast notification (optional)
- Navigation after delay

### Empty States
- Large icon/emoji
- Descriptive heading
- Helpful description
- Primary CTA button

### Hover/Focus States
- Smooth transitions
- Visible focus rings
- Color changes
- Slight scale increase

## Typography Hierarchy

### H1 (Page Title)
- font-size: 3rem (48px)
- font-weight: 700
- color: white
- margin-bottom: 1rem

### H2 (Section Title)
- font-size: 2rem (32px)
- font-weight: 700
- color: white
- margin-bottom: 1rem

### H3 (Card Title)
- font-size: 1.125rem (18px)
- font-weight: 600
- color: white
- margin-bottom: 0.5rem

### Body Text
- font-size: 1rem (16px)
- font-weight: 400
- color: gray-300
- line-height: 1.5

### Small Text
- font-size: 0.875rem (14px)
- font-weight: 500
- color: gray-400
- Used for: Labels, captions, helpers

## Usage Examples

### Button Styles
```html
<!-- Primary -->
<button class="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white font-semibold rounded-lg transition transform hover:scale-105">
  Action
</button>

<!-- Secondary -->
<button class="px-6 py-3 border border-primary-500 text-primary-400 hover:bg-primary-500 hover:text-white rounded-lg transition">
  Secondary
</button>

<!-- Disabled -->
<button disabled class="opacity-50 cursor-not-allowed">Disabled</button>
```

### Card Component
```html
<div class="bg-dark-800 bg-opacity-50 backdrop-blur-sm border border-dark-700 rounded-xl p-6 hover:border-primary-500 transition">
  <!-- Content -->
</div>
```

### Input Field
```html
<input 
  type="text"
  class="w-full px-4 py-3 bg-dark-700 border border-dark-600 rounded-lg text-white focus:outline-none focus:border-primary-500">
```

## Performance Considerations

### CSS Optimization
- Use Tailwind utilities
- Minimize custom CSS
- Use standard animations
- Avoid expensive properties

### Image Optimization
- Use placeholder emoji/colors
- Lazy load images
- WebP format if available
- Responsive images

### Animation Performance
- GPU-accelerated (transform, opacity)
- Avoid expensive properties (layout)
- Reduce animation duration on mobile
- Disable for prefers-reduced-motion

## Browser Support

- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- iOS Safari: Latest 2 versions
- Mobile Chrome: Latest 2 versions

### Fallbacks
- No CSS Grid fallback needed
- No Flexbox fallback needed
- Gradients have solid color fallback
- Backdrop blur graceful degradation
