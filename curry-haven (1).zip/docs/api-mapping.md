# API Mapping Documentation

This document maps frontend components to backend API endpoints.

## Base URL
```
http://localhost:8080/api
```

## Endpoints Used

### Films API
- **GET** `/api/films` - Get all films
- **GET** `/api/films/:id` - Get film by ID
- **POST** `/api/films` - Create new film (Staff)
- **PUT** `/api/films/:id` - Update film (Staff)
- **DELETE** `/api/films/:id` - Delete film (Staff)
- **GET** `/api/films/search?actorId=&categoryId=&languageId=&rating=&releaseYear=&maxPrice=` - Search films with filters

### Actors API
- **GET** `/api/actors` - Get all actors
- **GET** `/api/actors/:id` - Get actor by ID
- **POST** `/api/actors` - Create actor (Staff)
- **PUT** `/api/actors/:id` - Update actor (Staff)
- **DELETE** `/api/actors/:id` - Delete actor (Staff)

### Categories API
- **GET** `/api/categories` - Get all categories
- **GET** `/api/categories/:id` - Get category by ID
- **POST** `/api/categories` - Create category (Staff)
- **PUT** `/api/categories/:id` - Update category (Staff)
- **DELETE** `/api/categories/:id` - Delete category (Staff)

### Languages API
- **GET** `/api/languages` - Get all languages
- **GET** `/api/languages/:id` - Get language by ID
- **POST** `/api/languages` - Create language (Staff)
- **PUT** `/api/languages/:id` - Update language (Staff)
- **DELETE** `/api/languages/:id` - Delete language (Staff)

### Customers API
- **GET** `/api/customers` - Get all customers (Staff)
- **GET** `/api/customers/:id` - Get customer by ID
- **POST** `/api/customers` - Create new customer (Sign Up)
- **PUT** `/api/customers/:id` - Update customer
- **DELETE** `/api/customers/:id` - Delete customer (Staff)
- **GET** `/api/customers/email/:email` - Get customer by email

### Rentals API
- **GET** `/api/rentals` - Get all rentals (Staff)
- **GET** `/api/rentals/:id` - Get rental by ID
- **GET** `/api/rentals/customer/:customerId` - Get rentals for customer
- **POST** `/api/rentals` - Create rental
- **PUT** `/api/rentals/:id` - Update rental (Staff)
- **DELETE** `/api/rentals/:id` - Delete rental (Staff)
- **PATCH** `/api/rentals/:id/return` - Mark film as returned

### Payments API
- **GET** `/api/payments` - Get all payments (Staff)
- **GET** `/api/payments/:id` - Get payment by ID
- **GET** `/api/payments/customer/:customerId` - Get payments for customer
- **POST** `/api/payments` - Create payment
- **PUT** `/api/payments/:id` - Update payment (Staff)
- **DELETE** `/api/payments/:id` - Delete payment (Staff)

### Inventory API
- **GET** `/api/inventory` - Get all inventory
- **GET** `/api/inventory/:id` - Get inventory by ID
- **GET** `/api/inventory/film/:filmId` - Get inventory for film
- **GET** `/api/inventory/store/:storeId` - Get inventory for store
- **POST** `/api/inventory` - Create inventory entry (Staff)
- **PUT** `/api/inventory/:id` - Update inventory (Staff)
- **DELETE** `/api/inventory/:id` - Delete inventory (Staff)

## Service Files
- `src/app/services/film.service.ts` - Film API calls
- `src/app/services/actor.service.ts` - Actor API calls
- `src/app/services/category.service.ts` - Category API calls
- `src/app/services/language.service.ts` - Language API calls
- `src/app/services/customer.service.ts` - Customer API calls
- `src/app/services/rental.service.ts` - Rental API calls
- `src/app/services/payment.service.ts` - Payment API calls
- `src/app/services/inventory.service.ts` - Inventory API calls

## CORS Configuration
The backend Spring Boot application must have CORS enabled for `http://localhost:4200`.

Example configuration in Spring Boot:
```java
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins("http://localhost:4200")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}
```

## Error Handling
All services include error handling with observables. Errors are logged to console and displayed to users via error messages in components.

## Notes
- All API calls use Angular HttpClient
- No authentication/JWT required per specification
- Role-based authorization handled on frontend only
- Request/response models defined in `src/app/models/film.model.ts`
