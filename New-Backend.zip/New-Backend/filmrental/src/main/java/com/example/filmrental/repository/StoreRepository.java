package com.example.filmrental.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.filmrental.model.Address;
import com.example.filmrental.model.Store;

public interface StoreRepository extends JpaRepository<Store, Long> {

	Optional<Store> findByStoreNameIgnoreCase(String storeName);

}
