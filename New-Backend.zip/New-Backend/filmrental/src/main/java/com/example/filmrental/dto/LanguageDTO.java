//package com.example.filmrental.dto;
//
//import java.time.LocalDateTime;
//
//import jakarta.validation.constraints.NotBlank;
//
//public class LanguageDTO {
//	private Long Id;
//	@NotBlank
//	private String Name;
//	private LocalDateTime LastUpdate;
//}
