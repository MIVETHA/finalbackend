
package com.example.filmrental.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;


import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.AccessMode;

@Data
public class PaymentDTO {
	@Schema(accessMode = AccessMode.READ_ONLY)
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long paymentId;

    @NotNull
    private Long customerId;

    @NotNull
    private Long staffId;

    private Long rentalId;

    @NotNull
    @Positive
    private Double amount;          
    private LocalDateTime paymentDate;
    private LocalDateTime lastUpdate;

    
}
